package com.aeon.internal.models.request;

import java.util.List;

import com.aeon.internal.models.DColumns;
import com.aeon.internal.models.DOrder;
import com.aeon.internal.models.DSearch;

public class ReqDatatableParam {
	private int draw;
	private List<DColumns> columns;
	private List<DOrder> order;
	private int start;
	private int length;
	private DSearch search;
	
	public int getDraw() {
		return draw;
	}
	public void setDraw(int draw) {
		this.draw = draw;
	}
	public List<DColumns> getColumns() {
		return columns;
	}
	public void setColumns(List<DColumns> columns) {
		this.columns = columns;
	}
	public List<DOrder> getOrder() {
		return order;
	}
	public void setOrder(List<DOrder> order) {
		this.order = order;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public DSearch getSearch() {
		return search;
	}
	public void setSearch(DSearch search) {
		this.search = search;
	}
}
