package com.aeon.internal.models;


import java.io.Serializable;

import javax.naming.Name;

import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entry(objectClasses = {"top", "user", "person", "organizationalPerson"})
public final class LdapUser implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@JsonIgnore
	private Name id;

    private @Attribute(name = "sAMAccountName")
    String sAMAccountName;

    private @Attribute(name = "cn")
    String cn;

    private @Attribute(name = "displayname")
    String displayName;

    private @Attribute(name = "sn")
    String sn;
    
    private @Attribute(name = "userPrincipalName")
    String userPrincipalName;
    
    private @Attribute(name = "lastLogon")
    String lastLogon;
    
    private @Attribute(name = "employeeid")
    String employeeID;
    
    private @Attribute(name = "memberOf")
    String memberOf;

	public Name getId() {
		return id;
	}
	public String getsAMAccountName() {
		return sAMAccountName;
	}
	public void setsAMAccountName(String sAMAccountName) {
		this.sAMAccountName = sAMAccountName;
	}
	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public void setId(Name id) {
		this.id = id;
	}
	public String getUserPrincipalName() {
		return userPrincipalName;
	}
	public void setUserPrincipalName(String userPrincipalName) {
		this.userPrincipalName = userPrincipalName;
	}
	public String getLastLogon() {
		return lastLogon;
	}
	public void setLastLogon(String lastLogon) {
		this.lastLogon = lastLogon;
	}
	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public String getMemberOf() {
		return memberOf;
	}
	public void setMemberOf(String memberOf) {
		this.memberOf = memberOf;
	}
	
}
