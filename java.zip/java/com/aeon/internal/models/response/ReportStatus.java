package com.aeon.internal.models.response;

public class ReportStatus {
	private int executing;
	private int success;
	private int expired;
	private int failed;
	
	public ReportStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ReportStatus(int executing, int success, int expired, int failed) {
		super();
		this.executing = executing;
		this.success = success;
		this.expired = expired;
		this.failed = failed;
	}
	
	public int getExecuting() {
		return executing;
	}
	public void setExecuting(int executing) {
		this.executing = executing;
	}
	public int getSuccess() {
		return success;
	}
	public void setSuccess(int success) {
		this.success = success;
	}
	public int getExpired() {
		return expired;
	}
	public void setExpired(int expired) {
		this.expired = expired;
	}
	public int getFailed() {
		return failed;
	}
	public void setFailed(int failed) {
		this.failed = failed;
	}
	
}
