package com.aeon.internal.entities.primary;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "batch_job_instance")
public class BatchJobInstance implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "JOB_INSTANCE_ID") private int id;
	@Column(name = "JOB_NAME") private String jobName;
	@Column(name = "JOB_KEY") private String jobKey;
	
	@OneToOne
	@JoinColumn(name = "JOB_INSTANCE_ID", referencedColumnName = "JOB_INSTANCE_ID", insertable = false, updatable = false)
	private BatchJobExecution jobExecution;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobKey() {
		return jobKey;
	}
	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}
	public BatchJobExecution getJobExecution() {
		return jobExecution;
	}
	public void setJobExecution(BatchJobExecution jobExecution) {
		this.jobExecution = jobExecution;
	}

}
