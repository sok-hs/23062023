package com.aeon.internal.entities.primary;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "batch_step_execution")
public class BatchStepExecution {

	@Id
	@Column(name = "STEP_EXECUTION_ID") private int id;
	@Column(name = "STEP_NAME") private String stepName;
	@Column(name = "JOB_EXECUTION_ID", insertable = false, updatable = false) private int jobExecutionId;
	@Column(name = "CREATE_TIME") private Date createTime;
	@Column(name = "START_TIME") private Date startTime;
	@Column(name = "END_TIME") private Date endTime;
	@Column(name = "STATUS") private String status;
	@Column(name = "READ_COUNT") private int readCount;
	@Column(name = "WRITE_COUNT") private int writeCount;
	@Column(name = "EXIT_CODE") private String exitCode;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public int getJobExecutionId() {
		return jobExecutionId;
	}
	public void setJobExecutionId(int jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getReadCount() {
		return readCount;
	}
	public void setReadCount(int readCount) {
		this.readCount = readCount;
	}
	public int getWriteCount() {
		return writeCount;
	}
	public void setWriteCount(int writeCount) {
		this.writeCount = writeCount;
	}
	public String getExitCode() {
		return exitCode;
	}
	public void setExitCode(String exitCode) {
		this.exitCode = exitCode;
	}
}
