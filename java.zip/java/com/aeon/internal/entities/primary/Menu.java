package com.aeon.internal.entities.primary;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="menus")
public class Menu implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String menu_name;
	private float order_by;
	private String url;
	private String icon;
	private String parent_id;
	private boolean is_active;
	private String created_by;
	private Timestamp created_at;
	private String updated_by;
	private Timestamp updated_at;
	private boolean is_deleted;
	private String deleted_by;
	private Timestamp deleted_at;

	@Transient
	private List<Menu> child;

	
	public Menu() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Menu(String menu_name, String url, String icon, float order_by, String parent_id, String created_by, Timestamp created_at) {
		super();
		this.menu_name = menu_name;
		this.url = url;
		this.icon = icon;
		this.order_by = order_by;
		this.parent_id = parent_id;
		this.created_by = created_by;
		this.created_at = created_at;
	}
	
	public Menu(String menu_name, String url, String icon, String parent_id, boolean is_active) {
		super();
		this.menu_name = menu_name;
		this.url = url;
		this.icon = icon;
		this.parent_id = parent_id;
		this.is_active = is_active;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMenu_name() {
		return menu_name;
	}
	public void setMenu_name(String menu_name) {
		this.menu_name = menu_name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getParent_id() {
		return parent_id;
	}
	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}
	public List<Menu> getChild() {
		return child;
	}
	public void setChild(List<Menu> child) {
		this.child = child;
	}

	public boolean isIs_active() {
		return is_active;
	}

	public void setIs_active(boolean is_active) {
		this.is_active = is_active;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Timestamp getCreated_at() {
		return created_at;
	}

	public void setCreated_at(Timestamp created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public Timestamp getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(Timestamp updated_at) {
		this.updated_at = updated_at;
	}

	public boolean isIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(boolean is_deleted) {
		this.is_deleted = is_deleted;
	}

	public String getDeleted_by() {
		return deleted_by;
	}

	public void setDeleted_by(String deleted_by) {
		this.deleted_by = deleted_by;
	}

	public Timestamp getDeleted_at() {
		return deleted_at;
	}

	public void setDeleted_at(Timestamp deleted_at) {
		this.deleted_at = deleted_at;
	}

	public float getOrder_by() {
		return order_by;
	}

	public void setOrder_by(float order_by) {
		this.order_by = order_by;
	}
}
