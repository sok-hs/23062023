package com.aeon.internal.entities.primary;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "batch_job_execution")
public class BatchJobExecution implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "JOB_EXECUTION_ID") private int id;
	@Column(name = "JOB_INSTANCE_ID") private int jobInstanceId;
	@Column(name = "CREATE_TIME") private Timestamp createTime;
	@Column(name = "START_TIME") private Timestamp startTime;
	@Column(name = "END_TIME") private Timestamp endTime;
	@Column(name = "STATUS") private String status;
	@Column(name = "EXIT_CODE") private String exitCode;
	@Column(name = "EXIT_MESSAGE") private String exitMessage;
	
	@OneToOne
	@JoinColumn(name = "JOB_EXECUTION_ID", referencedColumnName = "JOB_EXECUTION_ID", insertable = false, updatable = false)
	private BatchStepExecution stepExecution;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getJobInstanceId() {
		return jobInstanceId;
	}
	public void setJobInstanceId(int jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Timestamp getEndTime() {
		return endTime;
	}
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getExitCode() {
		return exitCode;
	}
	public void setExitCode(String exitCode) {
		this.exitCode = exitCode;
	}
	public String getExitMessage() {
		return exitMessage;
	}
	public void setExitMessage(String exitMessage) {
		this.exitMessage = exitMessage;
	}
	public BatchStepExecution getStepExecution() {
		return stepExecution;
	}
	public void setStepExecution(BatchStepExecution stepExecution) {
		this.stepExecution = stepExecution;
	}
}
