package com.aeon.internal.entities.primary;

import javax.persistence.Table;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
@Table(name = "batch_job_history")
public class BatchJobHistory implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name = "job_instance_id") private int jobInstanceId;
	@Column(name = "export_by") private String exportBy;
	@Column(name = "cond") private String condition;
	@Column(name = "filename") private String filename;
	@Column(name = "status") private int status;
	@Column(name = "created_by") private String createdBy;
	@Column(name = "created_at") private Timestamp createdAt;
	@Column(name = "updated_by") private String updatedBy;
	@Column(name = "updated_at") private Timestamp updatedAt;
	
	@OneToOne
	@JoinColumn(name = "job_instance_id", referencedColumnName = "JOB_INSTANCE_ID", insertable = false, updatable = false)
	private BatchJobInstance jobInstance;
	
	public BatchJobHistory() {
		super();
	}

	public BatchJobHistory(String exportBy, String condition, String filename, int status, String createdBy,
			Timestamp createdAt) {
		super();
		this.exportBy = exportBy;
		this.condition = condition;
		this.filename = filename;
		this.status = status;
		this.createdBy = createdBy;
		this.createdAt = createdAt;
	}

	public BatchJobHistory(int jobInstanceId, String exportBy, String condition, String filename, int status,
			String createdBy, Timestamp createdAt) {
		super();
		this.jobInstanceId = jobInstanceId;
		this.exportBy = exportBy;
		this.condition = condition;
		this.filename = filename;
		this.status = status;
		this.createdBy = createdBy;
		this.createdAt = createdAt;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getJobInstanceId() {
		return jobInstanceId;
	}
	public void setJobInstanceId(int jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}
	public String getExportBy() {
		return exportBy;
	}
	public void setExportBy(String exportBy) {
		this.exportBy = exportBy;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Timestamp getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}
	public BatchJobInstance getJobInstance() {
		return jobInstance;
	}
	public void setJobInstance(BatchJobInstance jobInstance) {
		this.jobInstance = jobInstance;
	}
}
