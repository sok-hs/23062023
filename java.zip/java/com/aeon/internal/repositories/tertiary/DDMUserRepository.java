package com.aeon.internal.repositories.tertiary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.tertiary.DDMUser;

@Repository
public interface DDMUserRepository extends JpaRepository<DDMUser, Integer>{
	DDMUser findByNameIgnoreCase(String username);
	DDMUser findByEmailIgnoreCase(String email);
}
