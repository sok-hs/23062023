package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.BatchJobHistory;

@Repository
public interface BatchJobHistoryRepository extends JpaRepository<BatchJobHistory, Integer>{
	
	static String queryJobHistoryByJobAndUsername = "SELECT u.fullname as export_by, jh.*\r\n" + 
											"FROM batch_job_history jh\r\n" + 
											"INNER JOIN batch_job_instance ji ON ji.JOB_INSTANCE_ID = jh.job_instance_id\r\n" + 
											"INNER JOIN users u ON u.username = jh.export_by\r\n" + 
											"WHERE ji.JOB_NAME = :jobName AND jh.export_by = :username\r\n" + 
											"ORDER BY jh.created_at DESC\r\n" + 
											"LIMIT :start, :length";
	
	static String queryJobHistory = "SELECT u.fullname as export_by, jh.*\r\n" + 
									"FROM batch_job_history jh\r\n" + 
									"INNER JOIN batch_job_instance ji ON ji.JOB_INSTANCE_ID = jh.job_instance_id\r\n" + 
									"INNER JOIN users u ON u.username = jh.export_by\r\n" + 
									"ORDER BY jh.created_at DESC\r\n" + 
									"LIMIT :start, :length";
	static String queryJobHistoryByUsername = "SELECT u.fullname as export_by, jh.*\r\n" + 
									"FROM batch_job_history jh\r\n" + 
									"INNER JOIN batch_job_instance ji ON ji.JOB_INSTANCE_ID = jh.job_instance_id\r\n" + 
									"INNER JOIN users u ON u.username = jh.export_by\r\n" + 
									"WHERE jh.export_by = :username\r\n" + 
									"ORDER BY jh.created_at DESC\r\n" + 
									"LIMIT :start, :length";

	static String queryCountAllJobHistory = "SELECT COUNT(id) \r\n" + 
											"FROM batch_job_history \r\n";
	static String queryCountAllJobHistoryByUsername = "SELECT COUNT(id)\r\n" + 
													"FROM batch_job_history\r\n" + 
													"WHERE export_by = :username";
	static String queryCountAllJobHistoryByJobNameAndUsername = "SELECT COUNT(id)\r\n" + 
													"FROM batch_job_history jh\r\n" + 
													"INNER JOIN batch_job_instance ji ON ji.JOB_INSTANCE_ID = jh.job_instance_id\r\n" + 
													"WHERE ji.JOB_NAME = :jobName \r\n" + 
													"AND jh.export_by = :username";
	static String queryCountAllExpiredJobHistory = "SELECT COUNT(id)\r\n" + 
												"FROM batch_job_history\r\n" + 
												"WHERE `status` = 2";
	static String queryCountAllExpiredJobHistoryByUsername = "SELECT COUNT(id)\r\n" + 
															"FROM batch_job_history\r\n" + 
															"WHERE `status` = 2\r\n" + 
															"AND export_by = :username";
	
	static String queryAllJobHistory = "SELECT u.fullname AS export_by, jh.*\r\n" + 
									"FROM batch_job_history jh\r\n" + 
									"INNER JOIN batch_job_instance ji ON ji.JOB_INSTANCE_ID = jh.job_instance_id\r\n" + 
									"INNER JOIN batch_job_execution je ON je.JOB_INSTANCE_ID = ji.JOB_INSTANCE_ID\r\n" + 
									"INNER JOIN batch_step_execution se ON se.JOB_EXECUTION_ID = je.JOB_EXECUTION_ID\r\n" + 
									"INNER JOIN users u ON u.username = jh.export_by\r\n" + 
									"WHERE TRUE\r\n" + 
									"AND ((:username = '' OR :username IS NULL) OR jh.export_by = :username)\r\n" + 
									"AND ((:dateFrom = '' OR :dateFrom IS NULL) OR DATE(je.CREATE_TIME) >= :dateFrom )\r\n" + 
									"AND ((:dateTo = '' OR :dateTo IS NULL) OR DATE(je.CREATE_TIME) <= :dateTo)\r\n" + 
									"AND ((:reportName = '' OR :reportName IS NULL) OR ji.JOB_NAME = :reportName)\r\n" + 
									"AND ((:exportedBy = '' OR :exportedBy IS NULL) OR (:exportedBy = '' OR jh.export_by = :exportedBy))\r\n" + 
									"AND ((:reportStatus = '' OR :reportStatus IS NULL) OR se.EXIT_CODE = :reportStatus)\r\n" + 
									"ORDER BY jh.created_at DESC\r\n" + 
									"LIMIT :start, :length";
	
	static String queryReportCountByExitCode = "SELECT COUNT(*)\r\n" + 
										"FROM batch_job_history jh\r\n" + 
										"INNER JOIN batch_job_instance ji ON ji.JOB_INSTANCE_ID = jh.job_instance_id\r\n" + 
										"INNER JOIN batch_job_execution je ON je.JOB_INSTANCE_ID = ji.JOB_INSTANCE_ID\r\n" + 
										"INNER JOIN batch_step_execution se ON se.JOB_EXECUTION_ID = je.JOB_EXECUTION_ID\r\n" + 
										"WHERE jh.`status` != 2\r\n" +
										"AND se.EXIT_CODE = :exitCode";
	static String queryReportCountByUsernameAndExitCode = "SELECT COUNT(*)\r\n" + 
										"FROM batch_job_history jh\r\n" + 
										"INNER JOIN batch_job_instance ji ON ji.JOB_INSTANCE_ID = jh.job_instance_id\r\n" + 
										"INNER JOIN batch_job_execution je ON je.JOB_INSTANCE_ID = ji.JOB_INSTANCE_ID\r\n" + 
										"INNER JOIN batch_step_execution se ON se.JOB_EXECUTION_ID = je.JOB_EXECUTION_ID\r\n" + 
										"WHERE jh.`status` != 2\r\n" +
										"AND jh.export_by = :username\r\n" +
										"AND se.EXIT_CODE = :exitCode";
	
	BatchJobHistory findById(int id);
	List<BatchJobHistory> findAllByStatus(int status);
	
	@Query(value = queryAllJobHistory, nativeQuery = true)
	List<BatchJobHistory> findAllJob(@Param("dateFrom") String dateFrom, @Param("dateTo") String dateTo, @Param("reportName") String reportName, 
			@Param("exportedBy") String exportedBy, @Param("reportStatus") String reportStatus, @Param("username") String username, 
			@Param("start") int start, @Param("length") int length);
	
	@Query(value = queryJobHistory, nativeQuery = true)
	List<BatchJobHistory> findAllJobHistory( @Param("start") int start, @Param("length") int length);
	
	@Query(value = queryJobHistoryByUsername, nativeQuery = true)
	List<BatchJobHistory> findAllJobHistory(@Param("username") String username, @Param("start") int start, @Param("length") int length);
	
	@Query(value = queryJobHistoryByJobAndUsername, nativeQuery = true)
	List<BatchJobHistory> findAllJobHistoryByUsername(@Param("username") String username, @Param("jobName") String jobName, @Param("start") int start, @Param("length") int length);
	
	@Query(value = queryCountAllJobHistory, nativeQuery = true)
	int countAllJobHistory();
	
	@Query(value = queryCountAllExpiredJobHistory, nativeQuery = true)
	int countAllExpiredJobHistory();
	
	@Query(value = queryCountAllJobHistoryByUsername, nativeQuery = true)
	int countAllJobHistory(@Param("username") String username);
	
	@Query(value = queryCountAllJobHistoryByJobNameAndUsername, nativeQuery = true)
	int countAllJobHistory(@Param("jobName") String jobName, @Param("username") String username);
	
	@Query(value = queryCountAllExpiredJobHistoryByUsername, nativeQuery = true)
	int countAllExpiredJobHistory(@Param("username") String username);
	
	@Query(value = queryReportCountByExitCode, nativeQuery = true)
	int countByExitCode(@Param("exitCode")String exitCode);
	
	@Query(value = queryReportCountByUsernameAndExitCode, nativeQuery = true)
	int countByExitCode(String username, String exitCode);
}
