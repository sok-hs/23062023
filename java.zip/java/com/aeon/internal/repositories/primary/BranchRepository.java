package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.Branch;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Integer>{
	
	static String queryDatatableAllBranches = "SELECT * \r\n" + 
									"FROM branches \r\n" + 
									"WHERE is_deleted = 0\r\n" + 
									"ORDER BY branch_name\r\n" + 
									"LIMIT :start, :length";
	
	static String queryCountAllBranches = "SELECT COUNT(id)\r\n" + 
										"FROM branches \r\n" + 
										"WHERE is_deleted = 0";	
	static String queryBranchByBranchName = "SELECT * \r\n" + 
											"FROM branches \r\n" + 
											"WHERE TRIM(LOWER(branch_name)) = :branchName\r\n" + 
											"LIMIT 1";
	static String queryAllBranches = "SELECT *\r\n" + 
									"FROM branches\r\n" + 
									"WHERE is_deleted = :isDeleted\r\n" + 
									"ORDER BY branch_name";
	Branch findById(int id);
	
	@Query(value =  queryBranchByBranchName, nativeQuery = true)
	Branch findBranchByBranchName(@Param("branchName") String branchName);
	
	@Query(value = queryDatatableAllBranches, nativeQuery = true)
	List<Branch> findDatatableAllBranches(@Param("start") int start, @Param("length") int length);
	
	@Query(value = queryAllBranches, nativeQuery = true)
	List<Branch> findAllBranches(@Param("isDeleted") int isDeleted);
	
	@Query(value = queryCountAllBranches, nativeQuery = true)
	int countAllBranches();
}