package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.aeon.internal.entities.primary.BatchJobInstance;

public interface BatchJobInstanceRepository extends JpaRepository<BatchJobInstance, Integer>{
	static String queryAllReports = "SELECT *\r\n" + 
									"FROM batch_job_instance\r\n" + 
									"GROUP BY JOB_NAME\r\n" + 
									"ORDER BY JOB_NAME";
	
	@Query(value = queryAllReports, nativeQuery = true)
	List<BatchJobInstance> getAllReports();
}
