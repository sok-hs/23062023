package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.BatchJobSeq;

@Repository
public interface BatchJobSeqRepository extends JpaRepository<BatchJobSeq, Integer>{
	List<BatchJobSeq> findAll();
}
