package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.UserGroupDetail;

@Repository
public interface UserGroupRepository extends JpaRepository<UserGroupDetail, Integer>{

	static String queryByUserId = "SELECT *\r\n" + 
								"FROM user_group_details\r\n" + 
								"WHERE user_id = :userId\r\n" + 
								"AND is_deleted = :isDeleted";
	static String queryByGroupId = "SELECT *\r\n" + 
								"FROM user_group_details\r\n" + 
								"WHERE group_id = :groupId\r\n" + 
								"AND is_deleted = :isDeleted";
	static String queryByUserIdAndGroupId = "SELECT *\r\n" + 
											"FROM user_group_details\r\n" + 
											"WHERE user_id = :userId AND group_id = :groupId";
	
	@Query(value = queryByUserId, nativeQuery = true)
	List<UserGroupDetail> findByUserId(@Param("userId") String userId, @Param("isDeleted") int isDeleted);
	
	@Query(value = queryByGroupId, nativeQuery = true)
	List<UserGroupDetail> findByGroupId(@Param("groupId") String groupId, @Param("isDeleted") int isDeleted);
	
	@Query(value = queryByUserIdAndGroupId, nativeQuery = true)
	UserGroupDetail findByUserIdAndGroupId(@Param("userId") String userId, @Param("groupId") String groupId);
}
