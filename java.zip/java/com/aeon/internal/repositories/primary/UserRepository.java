package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	
	static String queryAllUsers = "SELECT u.*, GROUP_CONCAT(g.group_name) AS 'groups'\r\n" + 
									"FROM users u\r\n" + 
									"LEFT JOIN user_group_details ugd ON ugd.user_id = u.id\r\n" + 
									"LEFT JOIN `groups` g ON g.id = ugd.group_id\r\n" + 
									"WHERE u.is_deleted = 0\r\n" + 
									"GROUP BY u.username\r\n" + 
									"ORDER BY u.fullname \r\n" + 
									"LIMIT :start, :length";
	
	static String queryUsers = "SELECT * \r\n" + 
								"FROM users \r\n" + 
								"WHERE is_deleted = :isDeleted \r\n" + 
								"ORDER BY fullname ASC";
	static String queryUsersByBranch = "SELECT * \r\n" + 
									"FROM users \r\n" + 
									"WHERE branch_id = :branchId";
	
	static String queryCountAllUsers = "SELECT COUNT(id)\r\n" + 
									"FROM users\r\n" + 
									"WHERE is_deleted = 0";
	
	User findByUsername(String username);
	User findById(int id);
	
	@Query(value = queryUsers, nativeQuery = true)
	List<User> findUsers(@Param("isDeleted") int isDeleted);
	
	@Query(value = queryUsersByBranch, nativeQuery = true)
	List<User> findUsersByBranch(@Param("branchId") int branchId);
	
	@Query(value = queryAllUsers, nativeQuery = true)
	List<User> findAllUsers(@Param("start") int start, @Param("length") int length);
	
	@Query(value = queryCountAllUsers, nativeQuery = true)
	int countAllUsers();
}
