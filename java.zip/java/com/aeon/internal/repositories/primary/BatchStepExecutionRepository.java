package com.aeon.internal.repositories.primary;

public interface BatchStepExecutionRepository {

}
