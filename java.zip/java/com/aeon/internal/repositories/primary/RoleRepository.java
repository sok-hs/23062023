package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Integer> {
	
	static String queryRoleByUsername = "SELECT r.role_name \r\n" + 
										"FROM role_group_details rgd\r\n" + 
										"INNER JOIN roles r ON r.id = rgd.role_id\r\n" + 
										"INNER JOIN `groups` g ON g.id = rgd.group_id\r\n" + 
										"INNER JOIN user_group_details ugd ON ugd.group_id = g.id\r\n" + 
										"INNER JOIN users u ON u.id = ugd.user_id\r\n" + 
										"WHERE rgd.is_deleted = 0 " +
										"AND g.is_deleted = 0 " +
										"AND ugd.is_deleted = 0 " +
										"AND r.is_active = 1 " +
										"AND u.username = :username\r\n" + 
										"GROUP BY r.role_name";
	
	static String queryRoleMenuIdByUsername = "SELECT r.menu_id\r\n" + 
								 		"FROM role_group_details rgd\r\n" + 
								 		"INNER JOIN roles r ON r.id = rgd.role_id\r\n" + 
								 		"INNER JOIN menus m ON m.id = r.menu_id\r\n" + 
								 		"INNER JOIN `groups` g ON g.id = rgd.group_id\r\n" + 
								 		"INNER JOIN user_group_details ugd ON ugd.group_id = g.id\r\n" + 
								 		"INNER JOIN users u ON u.id = ugd.user_id\r\n" + 
								 		"WHERE rgd.is_deleted = 0\r\n" + 
								 		"AND g.is_deleted = 0 \r\n" + 
								 		"AND ugd.is_deleted = 0 \r\n" + 
								 		"AND r.is_active = 1 \r\n" + 
								 		"AND u.username = :username\r\n" + 
								 		"GROUP BY r.role_name\r\n" + 
								 		"ORDER BY m.order_by";
	
	static String queryFindRoleByGroupId = "SELECT r.*\r\n" + 
										"FROM role_group_details rgd\r\n" + 
										"INNER JOIN roles r ON r.id = rgd.role_id\r\n" + 
										"WHERE rgd.is_deleted = 0 AND r.is_active = 1 AND rgd.group_id = :groupId";
	
	static String queryFindRoleByMenuId = "SELECT *\r\n" + 
										"FROM roles\r\n" + 
										"WHERE menu_id = :menuId\r\n" + 
										"AND is_deleted = :isDeleted\r\n" + 
										"LIMIT 1";
	
	static String queryGetRoles = "SELECT m.menu_name AS menu_id, r.*\r\n" + 
									"FROM roles r\r\n" + 
									"LEFT JOIN menus m ON m.id = r.menu_id\r\n" + 
									"WHERE r.is_deleted = 0 \r\n" + 
									"ORDER BY r.role_name\r\n" + 
									"LIMIT :start, :length";
	static String queryCountAllRoles = "SELECT COUNT(id)\r\n" + 
									"FROM roles\r\n" + 
									"WHERE is_deleted = 0";
	
	static String queryFindByRoleName = "SELECT *\r\n" + 
									"FROM roles\r\n" + 
									"WHERE role_name = :roleName";
	
	static String queryGetAllRoles = "SELECT * "
									+ "FROM roles "
									+ "WHERE is_active = 1 "
									+ "AND is_deleted = 0 "
									+ "ORDER BY role_name";
	
	static String queryAllRoleTypes = "SELECT `type` FROM roles GROUP BY `type` ORDER BY `type`";
	
	public Role findById(int id);
	
	@Query(value = queryFindRoleByMenuId, nativeQuery = true)
	public Role findByMenuId(@Param("menuId") int menuId, @Param("isDeleted") int isDeleted);
	
	@Query(value = queryFindByRoleName, nativeQuery = true)
	Role findByRoleName(@Param("roleName") String roleName);
	
	@Query(value = queryRoleByUsername, nativeQuery = true)
	public List<String> findRoleByUsername(@Param("username") String username);
	
	@Query(value = queryRoleMenuIdByUsername, nativeQuery = true)
	public List<Integer> findRoleMenuIdByUsername(@Param("username") String username);
	
	@Query(value = queryAllRoleTypes, nativeQuery = true)
	public List<String> getAllRoleTypes();
	
	@Query(value = queryFindRoleByGroupId, nativeQuery = true)
	public List<Role> findRoleByGroupId(@Param("groupId") int groupId);
	
	@Query(value = queryCountAllRoles, nativeQuery = true)
	public int countAllRoles();
	
	@Query(value = queryGetRoles, nativeQuery = true)
	public List<Role> getRoles(@Param("start") int start, @Param("length") int length);
	
	@Query(value = queryGetAllRoles, nativeQuery = true)
	public List<Role> getAllRoles();

}
