package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.RoleGroupDetail;

@Repository
public interface RoleGroupRepository extends JpaRepository<RoleGroupDetail, Integer>{
	static String queryExistingRoleGroup = "SELECT *\r\n" + 
											"FROM role_group_details\r\n" + 
											"WHERE role_id = :roleId\r\n" + 
											" AND group_id = :groupId\r\n" + 
											" AND is_deleted = :isDeleted";
	
	static String queryRoleGroupByGroupId = "SELECT * \r\n" + 
											"FROM role_group_details \r\n" + 
											"WHERE group_id = :groupId AND is_deleted = 0";
	
	static String queryRoleGroupByRoleId = "SELECT * \r\n" + 
											"FROM role_group_details \r\n" + 
											"WHERE role_id = :roleId AND is_deleted = 0";
	
	@Query(value = queryExistingRoleGroup, nativeQuery = true)
	RoleGroupDetail findExistingRoleGroup(@Param("roleId") String roleId, @Param("groupId") String groupId, @Param("isDeleted") int isDeleted);
	
	@Query(value = queryRoleGroupByGroupId, nativeQuery = true)
	List<RoleGroupDetail> findByGroupId(@Param("groupId") String groupId);
	
	@Query(value = queryRoleGroupByRoleId, nativeQuery = true)
	List<RoleGroupDetail> findAllByRoleId(@Param("roleId") String roleId);
}
