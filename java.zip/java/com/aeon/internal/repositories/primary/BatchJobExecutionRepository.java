package com.aeon.internal.repositories.primary;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.BatchJobExecution;

@Repository
public interface BatchJobExecutionRepository extends JpaRepository<BatchJobExecution, Integer>{
	static String queryAllBatchJob = "SELECT * FROM batch_job_execution";
	
	@Query(value = queryAllBatchJob, nativeQuery = true)
	List<BatchJobExecution> getAllBatchJob();
}
