package com.aeon.internal.repositories.primary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aeon.internal.entities.primary.Group;

@Repository
public interface GroupRepository extends JpaRepository<Group, Integer>{
	static String queryGroupsByUserId = "SELECT g.*\r\n" + 
										"FROM user_group_details ugd\r\n" + 
										"INNER JOIN `groups` g ON g.id = ugd.group_id\r\n" + 
										"WHERE ugd.is_deleted = 0 AND ugd.user_id = :userId";
	static String queryGroupsByUsername = "SELECT g.*\r\n" + 
										"FROM user_group_details ugd\r\n" + 
										"INNER JOIN `groups` g ON g.id = ugd.group_id\r\n" +
										"INNER JOIN `users` u ON u.id = ugd.user_id\r\n" +
										"WHERE ugd.is_deleted = 0 AND g.is_deleted = 0 AND u.username = :username";
	static String queryAllGroup = "SELECT *\r\n" + 
									"FROM `groups`\r\n" + 
									"WHERE is_deleted = 0\r\n" + 
									"LIMIT :start, :length";
	static String queryCountAllGroup = "SELECT COUNT(id)\r\n" + 
										"FROM `groups`\r\n" + 
										"WHERE is_deleted = 0 ";

	static String queryExistGroup = "SELECT *\r\n" + 
									"FROM `groups`\r\n" + 
									"WHERE TRIM(LOWER(group_name)) = :groupName\r\n" + 
									"AND is_deleted = :isDeleted\r\n" + 
									"LIMIT 1";
	static String queryFindConcatGroup = "SELECT GROUP_CONCAT(g.group_name) AS 'group_name' \r\n" + 
										"FROM `groups` g\r\n" + 
										"LEFT JOIN user_group_details ugd ON ugd.group_id = g.id\r\n" + 
										"LEFT JOIN users u ON u.id = ugd.user_id\r\n" + 
										"WHERE g.is_deleted = 0 AND ugd.is_deleted = 0 AND u.username = :username";

	static String queryFindAllGroup = "SELECT * \r\n" + 
										"FROM `groups`\r\n" + 
										"WHERE is_deleted = 0";
	Group findById(int id);
	
	@Query(value = queryGroupsByUserId, nativeQuery = true)
	List<Group> findGroupByUserId(@Param("userId") int userId);
	
	@Query(value = queryGroupsByUsername, nativeQuery = true)
	List<Group> findGroupByUsername(@Param("username" ) String username);
	
	@Query(value = queryAllGroup, nativeQuery = true)
	List<Group> getAllGroups(@Param("start") int start, @Param("length") int length);
	
	@Query(value = queryCountAllGroup, nativeQuery = true)
	int countAllGroup();
	
	@Query(value = queryExistGroup, nativeQuery =  true)
	Group findExistGroupByGroupName(@Param("groupName") String groupName, @Param("isDeleted") int isDeleted);
	
	@Query(value = queryFindConcatGroup, nativeQuery = true)
	String findConcatGroupByUsername(@Param("username") String username);
	
	@Query(value = queryFindAllGroup, nativeQuery = true)
	List<Group> findAllGroups();
}