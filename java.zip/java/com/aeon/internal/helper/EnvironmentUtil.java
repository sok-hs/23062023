package com.aeon.internal.helper;

import java.io.File;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EnvironmentUtil {
	
	private static String applicationArtifact;
	private static String env;
	
	@Value("${application.artifact}")
    public void setArtifactStatic(String artifact){
		EnvironmentUtil.applicationArtifact = artifact;
    }
	
	@Value("${spring.profiles.active}")
    public void setEnvStatic(String env){
		EnvironmentUtil.env = env;
    }
	
	public static String getContext() {
		String context = "";
		switch (env) {
		case "drprod":
			context = "";
			break;
		case "prod":
			context = "";
			break;
		case "uat":
			context = "/" + applicationArtifact;
			break;
		case "dev":
			context = "/" + applicationArtifact;
			break;
		default:
			context = "/" + applicationArtifact;
			break;
		}
		return context;
	}
	public static String getDirectory() {
		String dir = "";
		String folder = applicationArtifact.replace("-", "_");
		switch (env) {
		case "prod":
			dir = "/opt/tomcat/storage/" + folder;
			break;
		case "drprod":
			dir = "/opt/tomcat/storage/" + folder;
			break;
		case "uat":
			dir = "/opt/tomcat/storage/" + folder;
			break;
		case "dev":
			dir = File.separator + "src";
			break;
		default:
			dir = File.separator + "src";
			break;
		}
		return dir;
	}
}
