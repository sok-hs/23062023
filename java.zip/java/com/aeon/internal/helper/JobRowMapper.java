package com.aeon.internal.helper;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/*
 * 
 * Custom Mapper for mapping between reader and writer
 * 
 * - Required an entity
 * - Entity must define properties as a public access modifier for allow this class to read the properties
 * 
 * */
public class JobRowMapper<T> implements RowMapper<T>{
	
	private T genericTypeObject;
	private Field[] fields;
	
	protected JobRowMapper(Class<T> obj)
	{
		try {
			this.genericTypeObject = obj.getDeclaredConstructor().newInstance();
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.fields = genericTypeObject.getClass().getDeclaredFields();
	}
	
	@Override
	public T mapRow(ResultSet rs, int rowNum) throws SQLException {
		try {
			this.genericTypeObject = (T) genericTypeObject.getClass().getDeclaredConstructor().newInstance();
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for (Field field : fields) {
			try {
				field.set(genericTypeObject, rs.getString(field.getName()));
			} catch (IllegalArgumentException | IllegalAccessException | SQLException e) {
				continue;
			}
		}
		return (T) genericTypeObject;
	}

}
