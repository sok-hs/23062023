package com.aeon.internal.helper;

public class EmailHelper {
	
	public static String exportSuccessSubject(String reportName)
	{
		return reportName + " exported successful";
	}
	public static String exportFailedSubject(String reportName)
	{
		return reportName + " exported failed";
	}
	
	public static String exportSuccessContent(String reportName, String recipient)
	{
		return "<html>"
				+ "<head></head>" 
				+ "<body>"
				+ "<p>"
				+ "Dear " + recipient + ", <br><br>"
				+ "Your " + reportName + " report is exported successfully. Please check through the web-portal.<br>"
				+ "</p>"
				+ "</body>"
				+ "</html>";
	}
	
	public static String exportFailedContent(String reportName, String recipient)
	{
		return "<html>"
				+ "<head></head>" 
				+ "<body>"
				+ "<p>"
				+ "Dear: " + recipient + ", <br><br>"
				+ "Your " + reportName + " report is failed, please try to export again. Please check through the web-portal.<br>"
				+ "</p>"
				+ "</body>"
				+ "</html>";
	}
}
