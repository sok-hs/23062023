package com.aeon.internal.helper;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.WritableResource;

import com.aeon.internal.entities.primary.User;
import com.aeon.internal.service.primary.UserService;

import org.springframework.batch.core.StepExecution;
/*
 * This class will be using for extending to any writer class
 * 
 * This class required an entity.
 * 
 * Any field that will be written as an excel file header will 
 * required to define the properties to public access modifier
 * */
public class CustomExcelItemWritter<T> implements ItemStreamWriter<T> {
	private static final Logger logger = LogManager.getLogger(String.class);
	
	@Autowired UserService userService;
	private SXSSFWorkbook wb;
    private WritableResource resource;
    private int row;
    private int rowData = 0;
    private int countTotal;
    private int currentSheet;
    private boolean isOpen = false;
    private StepExecution stepExecution;
    
    @BeforeStep
    public void beforeStepExecution(StepExecution stepExecution) {
    	this.stepExecution = stepExecution;
    }

	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
	    isOpen = true;
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() throws ItemStreamException {
		if (wb == null) {
	        return;
	    }
	    try (BufferedOutputStream bos = new BufferedOutputStream(resource.getOutputStream())) {
	        wb.write(bos);
	        bos.flush();
	        wb.close();
	    } catch (IOException ex) {
	    	ex.printStackTrace();
	    	logger.error(ex.getMessage());
	        throw new ItemStreamException("Error writing to output file", ex);
	    }
	    row = 0;
	    rowData = 0;
	    isOpen = false;
		
	}

	@Override
	public void write(List<? extends T> items) throws Exception {
		
		Field[] fields = items.get(0).getClass().getFields();
		String username = stepExecution.getJobParameters().getString("username");
		String filename = stepExecution.getJobParameters().getString("filename");
		String report = stepExecution.getJobParameters().getString("report");
		String condition = stepExecution.getJobParameters().getString("condition");
		String exportedDate = stepExecution.getJobParameters().getString("exportedDate");
		String exportedBy = stepExecution.getJobParameters().getString("exportedBy");
		User user = userService.findByUsername(exportedBy);
		
		if(user != null) {
			exportedBy = user.getFullname();
		}
		if(isOpen) {
			String path = EnvironmentUtil.getDirectory() + File.separator + username;
			File dir = new File(path);
			if(!dir.exists()) {
				dir.mkdir();
			}
			wb = new SXSSFWorkbook(5000);
			Sheet s = wb.createSheet("Sheet 1");
		    resource = new FileSystemResource(path + File.separator + filename);
		    row = 0;
		    countTotal = 0;
		    currentSheet = 0;
		    writeReportInfo(s, report, condition, exportedDate, exportedBy);
		    writeHeaderRow(s, fields);
		    isOpen = false;
		}
		
		currentSheet = (countTotal / 1000000) + 1;
		countTotal += items.size();
		Sheet s = wb.getSheet("Sheet " + currentSheet);
		
		if((countTotal % 1000000) == 50000) {
			int SheetNo = (countTotal / 1000000) + 1;
			s = wb.getSheet("Sheet " + SheetNo);
			if (s == null) {
				row = 0;
				s = wb.createSheet("Sheet " + SheetNo);
				s = wb.getSheet("Sheet " + SheetNo);
				writeHeaderRow(s, fields);
			}
		}
		
		for (T o : items) {
			row++; rowData++;
			Row r = s.createRow(row);
			int cell = 0;
			Cell cno = r.createCell(cell++);
			cno.setCellValue(rowData);
			for (Field field : fields) {
				Cell c = r.createCell(cell);
		        c.setCellValue(field.get(o) == null ? "": field.get(o).toString());
		        cell++;
			} 
	    }	
	}
	
	private void writeReportInfo(Sheet s, String reportName, String condition, String exportedDate, String exportedBy) {
		reportName = "Report: " + reportName;
		condition = "Condition: " + condition;
		exportedDate = "Exported Date: " + exportedDate;
		exportedBy = "Exported By: " + exportedBy;
		
		//Report Style
		Font rfont = wb.createFont();
		rfont.setBold(true);
		rfont.setFontHeightInPoints((short) 20);
		//rfont.setFontHeight((short) 25);;
		CellStyle csh = wb.createCellStyle();
	    //csh.setWrapText(true);
	    csh.setFont(rfont);
	    
	    //Style for normal data
	    Font nfont = wb.createFont();
	    nfont.setBold(true);
	    //nfont.setFontHeight((short) 14);
	    CellStyle nCellStyle = wb.createCellStyle();
	    nCellStyle.setFont(nfont);
	    
	    //Report 
	    Row rowReport = s.createRow(row);
	    Cell cellReport = rowReport.createCell(0);
	    cellReport.setCellValue(reportName);
	    cellReport.setCellStyle(csh);
	    s.addMergedRegion(new CellRangeAddress(row,row,0,3));
	    row++;
	    
	    //Condition
	    Row rowCond = s.createRow(row);
	    Cell cellCond = rowCond.createCell(0);
	    cellCond.setCellValue(condition);
	    cellCond.setCellStyle(nCellStyle);
	    s.addMergedRegion(new CellRangeAddress(row,row,0,3));
	    row++;
	    
	    //Exported Date
	    Row rowExportDate = s.createRow(row);
	    Cell cellExportData = rowExportDate.createCell(0);
	    cellExportData.setCellValue(exportedDate);
	    cellExportData.setCellStyle(nCellStyle);
	    s.addMergedRegion(new CellRangeAddress(row,row,0,3));
	    row++;
	    
	    //Exported By
	    Row rowExportBy = s.createRow(row);
	    Cell cellExportBy = rowExportBy.createCell(0);
	    cellExportBy.setCellValue(exportedBy);
	    cellExportBy.setCellStyle(nCellStyle);
	    s.addMergedRegion(new CellRangeAddress(row,row,0,3));
	    row++;
	    
	    //Give space 1 row
	    row++;
	   
	}

	private void writeHeaderRow(Sheet s, Field[] fields) {
	     CellStyle cs = wb.createCellStyle();
	     cs.setWrapText(true);
	     cs.setAlignment(HorizontalAlignment.LEFT);
	 
	     Row r = s.createRow(row);
	     r.setRowStyle(cs);
	     
	     int cell =0;
	     Font font = wb.createFont();
	     font.setBold(true);
	     CellStyle csh = wb.createCellStyle();
	     csh.setWrapText(true);
	     csh.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.index);
	     csh.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	     csh.setFont(font);
	     
	     Cell no = r.createCell(cell);
	     no.setCellValue("No.");
	     no.setCellStyle(csh);
	     s.setColumnWidth(cell, poiWidth(12.0));
	     cell++;
	     if (fields.length >0 ) {
	    	 for (Field field : fields) {
		    	 Cell c = r.createCell(cell);
			     c.setCellValue(field.getName());
			     c.setCellStyle(csh);
			     s.setColumnWidth(cell, poiWidth(18.0));
			     cell++;
			}
		}
	 }
	
	private int poiWidth(double width) {
       return (int) Math.round(width * 256 + 200);
   }

}
