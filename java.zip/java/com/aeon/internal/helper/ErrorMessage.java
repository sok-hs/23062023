package com.aeon.internal.helper;

public enum ErrorMessage {
	
	NOT_FOUND 		("Page not found."),
	INTERNAL_ERROR	("Internal Server Error"),
	NULL_POINTER	("Null Pointer Exception!"),
//	Group
	GROUP_EXIST("Group is existed"),
	GROUP_NOT_FOUND("Group not found"),
	GROUP_CANNOT_EDIT("You cannot edit this group"),
	GROUP_BEING_USED("This group is being used by other users"),
//	Menu
	MENU_EXIST("Menu is existed"),
	MENU_DUPLICATE_URL("Menu url is duplicated to other menus"),
	MENU_NOT_FOUND("Menu not found"),
	MENU_BEING_USED("This menu is being used by other role"),
	MENU_HAS_CHILDS("This menu has sub menus, Please delete all the sub menus before this"),
//	Role
	ROLE_EXIST("Role is existed"),
	ROLE_NOT_FOUND("Role not found"),
//	User
	USER_NOT_FOUND ("User not found"),
	USER_CREATE_FAIL ("Create user failed"),
	CANNOT_DELETE_YOURSELF("You cannot delete yourself"),
//	Branch
	BRANCH_EXIST("Branch is existed"),
	BRANCH_NOT_FOUND("Branch not found"),
	BRANCH_BEING_USED("This branch is being used by other users"),
//	LDAP
	LDAP_USER_NOT_FOUND("LDAP user not found"),
//	Download Error
	DOWNLOAD_FILE_NOT_FOUND("File not found. This file might be deleted."),
	DOWNLOAD_FAILED("Download Failed")
	;
	private String value;

	private ErrorMessage(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
