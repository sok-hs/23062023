package com.aeon.internal.helper;

import java.awt.TrayIcon;

public enum MessageEnum {
		NO_DATA("No data found"),
	   INTERNAL_SERVER_ERROR("Internal server error"),	
	   REQUEST_MESSAGE_MANDATORY("RequestMessage is mandatory"),
	   SERVICE_HEADER_MANDATORY("ServiceHeader is mandatory"),
	   THIRDPARTY_MANDATORY("Third Party is mandatory"),
	   THIRDPARTY_NOT_FOUND("Unknown Third Party"),
	   USERNAME_MANDATORY("Username is mandatory"),
	   PASSWORD_MANDATORY("Password is mandatory"),
	   USERNAME_NOT_FOUND("Unknown username"),
	   TOKEN_ID_NOT_FOUND("Token id is mandatory"),
	   TOKEN_ID_INVALID("Token id invalid"),
	   OTHER_ERROR("Other error"),
	   BLOCK_AREA_CONFLICT("Block area already exist"),
	   CONTRACT_NOT_FOUND("Reference number is mandatory"),
	   CONTRACT_LENGTH_NOT_CORRECT("Reference number should be 8 digits"),
	   UNKNOWN_CONTRACT("Unknown reference number"),
	   PAID_AMOUNT_NOT_MATCH("Paid Not Match With Amount"),
	   SUCCESSED("Transaction success"),
	   CUSTMER_CODE_NOT_FOUND("Customer code not found"),
	   CUSTMER_CODE_LENGTH_NOT_CORRECT("customer code sholud be 9 digits"),
	   CUSTMER_CODE_INVALID("Customer code invalid"),
	   CREATED("Created"),
	   APPLICATION_LOCKED_BY("This application is locked by ");

	   private TrayIcon.MessageType type;

	   private String text;

	   private MessageEnum(String text) {
	      this.text = text;
	      this.type = TrayIcon.MessageType.ERROR;
	   }

	   public TrayIcon.MessageType getType() {
	      return type;
	   }

	   public String getText() {
	      return text;
	   }

	   public static MessageEnum fromText(String text) {
	      if (text != null) {
	         for (MessageEnum message : values()) {
	            if (message.getText().equals(text)) {
	               return message;
	            }
	         }
	      }
	      return null;
	   }
}
