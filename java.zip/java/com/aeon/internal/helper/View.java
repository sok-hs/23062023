package com.aeon.internal.helper;

public final class View {
	public static String INDEX = "layout/index";
	public static String SETTING_USER="setting/user/index";
	public static String SECURITY_LOGIN = "login";
	
	public static String EMPLOYEE_INDEX ="employee/index";
	public static String EMPLOYEE_ADD ="employee/add";
	public static String EMPLOYEE_UPDATE ="employee/update";
	
	public static String PAYMENT_INDEX = "payment/index";
	public static String PAYMENT_LIMIT = "payment/export";

	public static String HOME = "home";
//	Report
	public static String REPORT_CBC = "report/cbc_report";
//	Export History
	public static String EXPORT_HISTORY_INDEX = "export-history/index";
	
//	Setting (User, Role, Menu)
	public static String MENU_INDEX = "setting/menu/index";
	public static String ROLE_INDEX = "setting/role/index";
	public static String GROUP_INDEX = "setting/group/index";
	public static String USER_INDEX = "setting/user/index";
	public static String BRANCH_INDEX = "setting/branch/index";
	
//	Error Page
	public static String ACCESS_DENIED = "error/401";
	public static String NOT_FOUND = "error/404";
}
