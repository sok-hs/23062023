package com.aeon.internal.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.aeon.internal.entities.primary.Menu;
import com.aeon.internal.service.primary.MenuService;
import com.aeon.internal.service.primary.MenuServiceImpl;

@Component
public class SidebarHelper {

	private List<Menu> realMenus;
	private MenuService menuService;
	
	
	public SidebarHelper(List<Menu> realMenus, MenuService menuService) {
		super();
		this.realMenus = realMenus;
		this.menuService = menuService;
	}
	
	public List<Menu> getRealMenus() {
		return realMenus;
	}
	public void setRealMenus(List<Menu> realMenus) {
		this.realMenus = realMenus;
	}
	public MenuService getMenuService() {
		return menuService;
	}
	public void setMenuService(MenuServiceImpl menuService) {
		this.menuService = menuService;
	}
	
	public List<Menu> calculateMenu(List<Integer> menuIds) {
		for (Integer menuId : menuIds) {
			Menu menu = menuService.findById(menuId.intValue());
			if(menu !=null) {
				if(menu.getParent_id() == null) {
					realMenus.add(menu);
				}else {
					//exiting parent
					int parentIdex = 0;
					boolean parentExist = false;
					for (int i = 0; i < realMenus.size(); i++) {
						if(Integer.parseInt(menu.getParent_id()) == realMenus.get(i).getId()) {
							parentExist = true;
							parentIdex = i;
							break;
						}
					}
					
					if(parentExist) {
						List<Menu> chiList = realMenus.get(parentIdex).getChild();
						chiList.add(menu);
						realMenus.get(parentIdex).setChild(chiList);
					}else {
						//new parent
						Menu parent = menuService.findById(Integer.parseInt(menu.getParent_id()));
						if(parent !=null) {
							List<Menu> chiList = new ArrayList<Menu>();
							chiList.add(menu);
							parent.setChild(chiList);
							realMenus.add(parent);
						}	
					}
				}
			}
		}
		return realMenus;
	}
	
}
