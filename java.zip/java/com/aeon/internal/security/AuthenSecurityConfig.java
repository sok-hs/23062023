package com.aeon.internal.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

import com.aeon.internal.component.CustomAuthenticationFailureHanlder;
import com.aeon.internal.configuration.CustomAuthenticationProvider;
import com.aeon.internal.configuration.CustomAuthenticationSuccessHanlder;

@Configuration
@EnableWebSecurity
public class AuthenSecurityConfig{
	
	@Autowired private CustomAuthenticationProvider customAuthenticationProvider;
	@Autowired private CustomAuthenticationFailureHanlder customAuthenticationFailureHanlder;
	@Autowired private CustomAuthenticationSuccessHanlder customAuthenticationSuccessHanlder;
	
	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		return (web)-> web.ignoring().antMatchers("/plugins/**", "/dist/**", "/myfiles/**");
	}
	
	@Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		
		http
			.csrf().disable()
			.authorizeRequests()
				.antMatchers("/security/**", "/error/**")
				.permitAll()
				.antMatchers("/", "/setting/user/all-users", "/setting/branch/all-branch").authenticated()
				.antMatchers("/setting/user/**").hasAnyAuthority("USER_INDEX")
				.antMatchers("/setting/group/**").hasAnyAuthority("GROUP_INDEX")
				.antMatchers("/setting/role/**").hasAnyAuthority("ROLE_INDEX")
				.antMatchers("/setting/menu/**").hasAnyAuthority("MENU_INDEX")
				.antMatchers("/setting/branch/**").hasAnyAuthority("BRANCH_INDEX")
				.anyRequest().denyAll()
			.and()
				.formLogin()
				.loginPage("/security/login")
				.successHandler(customAuthenticationSuccessHanlder)
				.failureHandler(customAuthenticationFailureHanlder)
				.permitAll()
			.and()
				.logout()
				.logoutUrl("/logout")
				.logoutSuccessUrl("/security/login?logout")
				.invalidateHttpSession(true)
				.clearAuthentication(true)
				.permitAll()
			.and()
					.sessionManagement()
					.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
					.invalidSessionUrl("/security/login")
					.maximumSessions(1)
					.expiredUrl("/security/expired")
					.and()
			.and()
				.exceptionHandling().accessDeniedPage("/error/401")
			.and()
				.authenticationProvider(customAuthenticationProvider)
		;
        return http.build();
    }

}
