package com.aeon.internal.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.aeon.internal.helper.AjaxMessage;
import com.aeon.internal.helper.ErrorMessage;

@ControllerAdvice(basePackages = {"com.aeon.internal.controller.web"})
public class WebControllerAdvice {

	private final String defaultExceptionView = "/error/exception";

	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public String nullException(Exception ex, AjaxMessage message,
			RedirectAttributes redirectAttributes) {

		message.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		message.setTitle(ErrorMessage.INTERNAL_ERROR.getValue());
		message.setDetail(ex.getMessage().toString());
		redirectAttributes.addAttribute("message", message);
		return "redirect:" + this.defaultExceptionView;
	}
}
