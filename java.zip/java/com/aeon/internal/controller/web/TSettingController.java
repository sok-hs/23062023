package com.aeon.internal.controller.web;

import org.springframework.web.bind.annotation.RequestMapping;

import com.aeon.internal.annotation.WebController;

@WebController
@RequestMapping("/setting")
public class TSettingController {

}
