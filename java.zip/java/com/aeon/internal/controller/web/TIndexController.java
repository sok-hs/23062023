package com.aeon.internal.controller.web;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.aeon.internal.annotation.WebController;
import com.aeon.internal.entities.primary.Group;
import com.aeon.internal.entities.primary.Menu;
import com.aeon.internal.entities.primary.User;
import com.aeon.internal.helper.EnvironmentUtil;
import com.aeon.internal.helper.SidebarHelper;
import com.aeon.internal.helper.View;
import com.aeon.internal.service.primary.GroupService;
import com.aeon.internal.service.primary.MenuService;
import com.aeon.internal.service.primary.RoleService;
import com.aeon.internal.service.primary.UserService;

@WebController
public class TIndexController {
	
	@Autowired private UserService userService;
	@Autowired private RoleService roleService;
	@Autowired private GroupService groupService;
	@Autowired private MenuService menuService;
	@Autowired private SidebarHelper sidebarHelper;
	
	@GetMapping("/")
    public String index(Model model) {
		String context = EnvironmentUtil.getContext();
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");  
	    User user = userService.findByUsername(username);
	    List<String> roles = roleService.findRoleByUsername(username);
	    List<Group> groups = groupService.findGroupByUsername(username);
		List<Integer> menuIds = roleService.findRoleObjByUsername(username);		
		List<Menu> realMenus = new ArrayList<Menu>();
		sidebarHelper = new SidebarHelper(realMenus, menuService);
		realMenus = sidebarHelper.calculateMenu(menuIds);
		
	    String version = getClass().getPackage().getImplementationVersion();
	    
	    model.addAttribute("username", username);
	    model.addAttribute("fullname", user.getFullname());
        model.addAttribute("menus", realMenus);
        model.addAttribute("groups", groups);
        model.addAttribute("systemDate",new Date());
        model.addAttribute("roles", roles);
        model.addAttribute("lastLogin", formatter.format(null == user.getLast_login() ? new Date() : user.getLast_login() ));
        model.addAttribute("version", version);
        model.addAttribute("context", context);
        
        return View.INDEX;
    }
}
