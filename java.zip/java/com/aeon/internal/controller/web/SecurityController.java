package com.aeon.internal.controller.web;

import org.springframework.http.HttpStatus;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.aeon.internal.annotation.WebController;
import com.aeon.internal.helper.AjaxMessage;
import com.aeon.internal.helper.View;

@WebController
@RequestMapping("/security")
public class SecurityController {
	
	@RequestMapping("/login")
	public String login(AjaxMessage ajaxMessage, @RequestParam(required = false, value = "error") boolean error, ModelMap map) {
		
		if(error){
			ajaxMessage.setResult(false);
			ajaxMessage.setStatus(HttpStatus.UNAUTHORIZED);
			ajaxMessage.setTitle("Invalid Username/Password");
			map.addAttribute("message", ajaxMessage);
		}
		
		return View.SECURITY_LOGIN;
	}
	

	@RequestMapping("/denied")
	public String denied(AjaxMessage ajaxMessage, ModelMap map){
		
		ajaxMessage.setResult(false);
		ajaxMessage.setStatus(HttpStatus.UNAUTHORIZED);
		ajaxMessage.setTitle("Access Denied.");
		map.addAttribute("message", ajaxMessage);
		
		return View.SECURITY_LOGIN;
	}
	

	@RequestMapping("/expired")
	public String expired(AjaxMessage ajaxMessage, ModelMap map){

		ajaxMessage.setResult(false);
		ajaxMessage.setStatus(HttpStatus.UNAUTHORIZED);
		ajaxMessage.setTitle("User Session expired.");
		map.addAttribute("message", ajaxMessage);
		
		return View.SECURITY_LOGIN;
	}
	
	@RequestMapping("/locked")
	public String locked(AjaxMessage ajaxMessage, ModelMap map)
	{
		ajaxMessage.setResult(false);
		ajaxMessage.setStatus(HttpStatus.UNAUTHORIZED);
		ajaxMessage.setTitle("User locked");
		map.addAttribute("message", ajaxMessage);
		
		return View.SECURITY_LOGIN;
	}

}
