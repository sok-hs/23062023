package com.aeon.internal.controller.ajax;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.aeon.internal.annotation.AjaxController;
import com.aeon.internal.entities.primary.Menu;
import com.aeon.internal.entities.primary.Role;
import com.aeon.internal.helper.ErrorMessage;
import com.aeon.internal.helper.ObjResponseEntity;
import com.aeon.internal.helper.ObjResponseFactory;
import com.aeon.internal.helper.StatusMessageEnum;
import com.aeon.internal.models.request.ReqDatatableParam;
import com.aeon.internal.models.response.ResDatatableParam;
import com.aeon.internal.service.primary.MenuService;
import com.aeon.internal.service.primary.RoleService;

@AjaxController
@Transactional
@RequestMapping("/setting/role")
public class RoleController {
	private static final Logger logger = LogManager.getLogger(String.class);
	
	@Autowired private RoleService roleService;
	@Autowired private MenuService menuService;

	@PostMapping("/datatable")
	public ResDatatableParam<Role> index(@RequestBody ReqDatatableParam data)
	{
		try {
			List<Role> roles = roleService.getRoles(data.getStart(), data.getLength());
			int countRoles = roleService.countAllRoles();
			return new ResDatatableParam<Role>(data.getDraw(), countRoles, countRoles, roles);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return null;
	}
	
	
	@PostMapping("/create")
	public ObjResponseEntity<String> createRole(@RequestBody Role data)
	{
		try {
			Timestamp now = Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			String roleName = data.getRole_name().toUpperCase();
			String type = data.getType().toUpperCase();
			String menuId = data.getMenu_id();
			boolean isActive = true;
			
			Role role = new Role(roleName, type, menuId, isActive, authUsername, now);
			if(roleService.save(role)) {
				return ObjResponseFactory.success();
			}else{
				return ObjResponseFactory.fail(ErrorMessage.ROLE_EXIST.getValue(), StatusMessageEnum.CONFLICT.getStatusCode());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/edit")
	public ObjResponseEntity<String> roleEdit(@RequestBody Role data)
	{
		try {
			Timestamp now = Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			Menu menu = null;
			Role oldRole = roleService.findById(data.getId());
			
			if(data.getMenu_id() != null && !data.getMenu_id().isEmpty()) {				
				menu = menuService.findById(Integer.parseInt(data.getMenu_id()));
			}
			
			if(oldRole == null) {
				return ObjResponseFactory.fail(ErrorMessage.ROLE_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			if(menu == null && data.getMenu_id() != null && !data.getMenu_id().isEmpty()) {
				return ObjResponseFactory.fail(ErrorMessage.MENU_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			
			if(roleService.findByRoleName(data.getRole_name().toLowerCase()) != null && !oldRole.getRole_name().toLowerCase().equals(data.getRole_name().toLowerCase())) {
				return ObjResponseFactory.fail(ErrorMessage.ROLE_EXIST.getValue(), StatusMessageEnum.CONFLICT.getStatusCode());
			}
			
			if(menu != null) {
				oldRole.setMenu_id(String.valueOf(menu.getId()));
			}else {
				oldRole.setMenu_id(null);
			}
			oldRole.setRole_name(data.getRole_name().toUpperCase());
			oldRole.setType(data.getType().toUpperCase());

			oldRole.setIs_active(data.isIs_active());
			oldRole.setUpdated_at(now);
			oldRole.setUpdated_by(authUsername);
			if(roleService.save(oldRole)) {					
				return ObjResponseFactory.success();
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/info")
	public ObjResponseEntity<Role> roleInfo(@RequestBody Role data)
	{
		try {
			Role role = roleService.findById(data.getId());
			return ObjResponseFactory.build(role);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@GetMapping("/all")
	public ObjResponseEntity<List<Role>> allRoles()
	{
		try {
			List<Role> roles = roleService.getAllRoles();
			return ObjResponseFactory.build(roles);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@GetMapping("/all-types")
	public ObjResponseEntity<List<String>> allRoleTypes(){
		try {
			List<String> roleTypes = roleService.getAllRoleTypes();
			return ObjResponseFactory.build(roleTypes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ObjResponseFactory.fail();
	}
}
