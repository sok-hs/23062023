package com.aeon.internal.controller.ajax;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.aeon.internal.annotation.AjaxController;
import com.aeon.internal.entities.primary.Menu;
import com.aeon.internal.entities.primary.Role;
import com.aeon.internal.entities.primary.RoleGroupDetail;
import com.aeon.internal.helper.ErrorMessage;
import com.aeon.internal.helper.ObjResponseEntity;
import com.aeon.internal.helper.ObjResponseFactory;
import com.aeon.internal.helper.StatusMessageEnum;
import com.aeon.internal.models.request.ReqDatatableParam;
import com.aeon.internal.models.response.ResDatatableParam;
import com.aeon.internal.service.primary.MenuService;
import com.aeon.internal.service.primary.RoleGroupService;
import com.aeon.internal.service.primary.RoleService;

@RequestMapping(value = "/setting/menu")
@AjaxController
@Transactional
public class MenuController {
	private static final Logger logger = LogManager.getLogger(String.class);

	@Autowired private MenuService menuService;
	@Autowired private RoleService roleService;
	@Autowired private RoleGroupService roleGroupService;

	@PostMapping("/datatable")
	public ResDatatableParam<Menu> index(@RequestBody ReqDatatableParam data) {
		try {
			List<Menu> menus = menuService.getMenus(data.getLength(), data.getStart());
			int countMenus = menuService.countAllMenus();
			return new ResDatatableParam<Menu>(data.getDraw(), countMenus, countMenus, menus);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return null;
	}

	@PostMapping("/create")
	public ObjResponseEntity<String> createMenu(@RequestBody Menu data) {
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();

			String menuName = data.getMenu_name();
			String menuParent = data.getParent_id();
			String menuUrl = data.getUrl().toLowerCase();
			String menuIcon = data.getIcon();
			float menuOrderBy = data.getOrder_by();
			Menu newMenu = new Menu(menuName, menuUrl, menuIcon, menuOrderBy, menuParent, auth.getName(), now);
			if (menuService.existByMenuName(newMenu.getMenu_name().toLowerCase(), 0) != null) {
				return ObjResponseFactory.fail(ErrorMessage.MENU_EXIST.getValue(),
						StatusMessageEnum.CONFLICT.getStatusCode());
			}
			if (menuService.existByMenuUrl(newMenu.getUrl().toLowerCase()) > 0) {
				return ObjResponseFactory.fail(ErrorMessage.MENU_DUPLICATE_URL.getValue(),
						StatusMessageEnum.CONFLICT.getStatusCode());
			}

			Menu oldMenu = menuService.existByMenuName(newMenu.getMenu_name().toLowerCase(), 1);
			if (oldMenu != null) {
				oldMenu.setMenu_name(newMenu.getMenu_name());
				oldMenu.setUrl(newMenu.getUrl());
				oldMenu.setIcon(newMenu.getIcon());
				oldMenu.setOrder_by(newMenu.getOrder_by());
				oldMenu.setParent_id(newMenu.getParent_id());
				oldMenu.setIs_active(true);
				oldMenu.setCreated_by(newMenu.getCreated_by());
				oldMenu.setCreated_at(newMenu.getCreated_at());
				oldMenu.setUpdated_by(null);
				oldMenu.setUpdated_at(null);
				oldMenu.setIs_deleted(false);
				oldMenu.setDeleted_at(null);
				oldMenu.setDeleted_by(null);
				menuService.save(oldMenu);
			} else {
				menuService.save(newMenu);
			}

			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}

	@PostMapping("/info")
	public ObjResponseEntity<Menu> menuInfo(@RequestBody Menu data) {
		try {
			Menu menu = menuService.findById(data.getId());
			return ObjResponseFactory.build(menu);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}

	@PostMapping("/edit")
	public ObjResponseEntity<String> editMenu(@RequestBody Menu data) {
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			Menu oldMenu = menuService.findById(data.getId());
			if (menuService.existByMenuName(data.getMenu_name().toLowerCase(), 0) != null
					&& !oldMenu.getMenu_name().toLowerCase().equals(data.getMenu_name().toLowerCase())) {
				return ObjResponseFactory.fail(ErrorMessage.MENU_EXIST.getValue(),
						StatusMessageEnum.CONFLICT.getStatusCode());
			}
			if (menuService.existByMenuUrl(data.getUrl().toLowerCase()) > 0
					&& !oldMenu.getUrl().toLowerCase().equals(data.getUrl().toLowerCase())) {
				return ObjResponseFactory.fail(ErrorMessage.MENU_DUPLICATE_URL.getValue(),
						StatusMessageEnum.CONFLICT.getStatusCode());
			}

			oldMenu.setMenu_name(data.getMenu_name());
			oldMenu.setParent_id(data.getParent_id());
			oldMenu.setOrder_by(data.getOrder_by());
			oldMenu.setUrl(data.getUrl());
			oldMenu.setIcon(data.getIcon());
			oldMenu.setUpdated_at(now);
			oldMenu.setUpdated_by(auth.getName());
			menuService.save(oldMenu);
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}

	@PostMapping("/delete")
	public ObjResponseEntity<String> deleteMenu(@RequestBody Menu data) {
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			List<RoleGroupDetail> roleGroups = new ArrayList<RoleGroupDetail>();
			Menu oldMenu = menuService.findById(data.getId());
			Role role = roleService.findByMenuId(oldMenu.getId(), 0);
			if (oldMenu.getParent_id() == null) {
				List<Menu> childMenus = menuService.findAllByParentId(String.valueOf(oldMenu.getId()), 10);
				if (childMenus.size() > 0) {
					return ObjResponseFactory.fail(ErrorMessage.MENU_HAS_CHILDS.getValue(),
							StatusMessageEnum.CONFLICT.getStatusCode());
				}
			}
			if (role != null) {
				role.setMenu_id(null);
				roleGroups = roleGroupService.findByRoleId(String.valueOf(role.getId()));
			}

			if (roleGroups.size() <= 0) {
				oldMenu.setIs_active(false);
				oldMenu.setIs_deleted(true);
				oldMenu.setDeleted_at(now);
				oldMenu.setDeleted_by(auth.getName());
				if (role != null) {
					roleService.save(role);
				}
				menuService.save(oldMenu);
			} else {
				return ObjResponseFactory.fail(ErrorMessage.MENU_BEING_USED.getValue(),
						StatusMessageEnum.FORBIDDEN.getStatusCode());
			}

			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}

	@GetMapping("/all")
	public ObjResponseEntity<List<Menu>> allMenus() {
		try {

			List<Menu> menus = menuService.getAllMenus();
			return ObjResponseFactory.build(menus);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}

	@GetMapping("/parents")
	public ObjResponseEntity<List<Menu>> allParentMenus() {
		try {
			List<Menu> parents = menuService.getParentMenus();
			return ObjResponseFactory.build(parents);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}

		return ObjResponseFactory.fail();
	}
}
