package com.aeon.internal.controller.ajax;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.aeon.internal.annotation.AjaxController;
import com.aeon.internal.entities.primary.Branch;
import com.aeon.internal.entities.primary.User;
import com.aeon.internal.helper.ErrorMessage;
import com.aeon.internal.helper.ObjResponseEntity;
import com.aeon.internal.helper.ObjResponseFactory;
import com.aeon.internal.helper.StatusMessageEnum;
import com.aeon.internal.models.TBranch;
import com.aeon.internal.models.request.ReqDatatableParam;
import com.aeon.internal.models.response.ResDatatableParam;
import com.aeon.internal.service.primary.BranchService;
import com.aeon.internal.service.primary.UserService;


@AjaxController
@RequestMapping("/setting/branch")
@Transactional
public class BranchController {
private static final Logger logger = LogManager.getLogger(BranchController.class);
	

	@Autowired private BranchService branchService;
	@Autowired private UserService userService;
	
	@PostMapping("/datatable")
	public ResDatatableParam<Branch> index(@RequestBody ReqDatatableParam data)
	{
		try {
			List<Branch> branches = branchService.findDatatableAllBranches(data.getStart(), data.getLength());
			int countBraches = branchService.countAllBranch();
			return new ResDatatableParam<Branch>(data.getDraw(), countBraches, countBraches, branches);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return null;
	}
	
	@PostMapping("/create")
	public ObjResponseEntity<String> groupCreate(@RequestBody TBranch data)
	{
		try {
			Timestamp now = Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			String branchName = data.getBranchName();
			String branchCode = data.getBranchCode();
			Branch existBranch = branchService.findExistBranchByBranchName(branchName);
			if(existBranch == null) {
				Branch branch = new Branch(branchName, branchCode, true, now, authUsername, false);
				branchService.save(branch);
				return ObjResponseFactory.success();
			}else {
				if (existBranch.isDeleted()) {
					existBranch.setBranchName(branchName);
					existBranch.setBranchCode(branchCode);
					existBranch.setActive(true);
					existBranch.setCreatedAt(now);
					existBranch.setCreatedBy(authUsername);
					existBranch.setUpdatedAt(null);
					existBranch.setUpdatedBy(null);
					existBranch.setDeleted(false);
					existBranch.setDeleted_at(null);
					existBranch.setDeletedBy(null);
					return ObjResponseFactory.success();
				}else {
					return ObjResponseFactory.fail(ErrorMessage.BRANCH_EXIST.getValue(), StatusMessageEnum.CONFLICT.getStatusCode());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/info")
	public ObjResponseEntity<Branch> groupInfo(@RequestBody TBranch data)
	{
		try {
			Branch branch = branchService.findById(data.getId());
			if(branch == null) {
				return ObjResponseFactory.fail(ErrorMessage.BRANCH_NOT_FOUND.getValue(), StatusMessageEnum.NOT_FOUND.getStatusCode());
			}
			return ObjResponseFactory.build(branch);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/edit")
	public ObjResponseEntity<String> groupEdit(@RequestBody TBranch data)
	{
		try {
			Timestamp now = Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			Branch branch = branchService.findById(data.getId());
			
			if(branch == null) {
				return ObjResponseFactory.fail(ErrorMessage.BRANCH_NOT_FOUND.getValue(), StatusMessageEnum.NOT_FOUND.getStatusCode());
			}
			
			branch.setBranchName(data.getBranchName());
			branch.setBranchCode(data.getBranchCode());
			branch.setUpdatedAt(now);
			branch.setUpdatedBy(authUsername);
			branchService.save(branch);
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/delete")
	public ObjResponseEntity<String> groupDelete(@RequestBody TBranch data)
	{
		try {
			Timestamp now = Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			Branch branch = branchService.findById(data.getId());
			if(branch == null) {
				return ObjResponseFactory.fail();
			}
			List<User> users = userService.findUsersByBranch(branch.getId());
			if(users.size() > 0) {
				return ObjResponseFactory.fail(ErrorMessage.BRANCH_BEING_USED.getValue(), StatusMessageEnum.FORBIDDEN.getStatusCode());
			}
			
			branch.setActive(false);
			branch.setDeleted(true);
			branch.setDeleted_at(now);
			branch.setDeletedBy(authUsername);
			branchService.save(branch);
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@GetMapping("/all-branch")
	public ObjResponseEntity<List<Branch>> getAllBranch()
	{
		try {
			List<Branch> branches = branchService.findAllBranches(0);
			return ObjResponseFactory.build(branches);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
}
