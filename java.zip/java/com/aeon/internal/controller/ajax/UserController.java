package com.aeon.internal.controller.ajax;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.aeon.internal.annotation.AjaxController;
import com.aeon.internal.entities.primary.Branch;
import com.aeon.internal.entities.primary.Group;
import com.aeon.internal.entities.primary.User;
import com.aeon.internal.entities.primary.UserGroupDetail;
import com.aeon.internal.entities.tertiary.DDMUser;
import com.aeon.internal.helper.ErrorMessage;
import com.aeon.internal.helper.ObjResponseEntity;
import com.aeon.internal.helper.ObjResponseFactory;
import com.aeon.internal.helper.StatusMessageEnum;
import com.aeon.internal.models.LdapUser;
import com.aeon.internal.models.TUser;
import com.aeon.internal.models.request.ReqDatatableParam;
import com.aeon.internal.models.response.ResDatatableParam;
import com.aeon.internal.service.LdapUserService;
import com.aeon.internal.service.primary.BranchService;
import com.aeon.internal.service.primary.GroupService;
import com.aeon.internal.service.primary.UserGroupService;
import com.aeon.internal.service.primary.UserService;
import com.aeon.internal.service.tertiary.DDMUserService;

@AjaxController
@RequestMapping("/setting/user")
@Transactional
public class UserController {
	private static final Logger logger = LogManager.getLogger(String.class);
	
	@Autowired private UserService userService;
	@Autowired private GroupService groupService;
	@Autowired private BranchService branchService;
	@Autowired private UserGroupService userGroupService;
	@Autowired private LdapUserService ldapUserService;
	@Autowired private DDMUserService ddmUserService;

	@PostMapping("/datatable")
	public ResDatatableParam<TUser> index(@RequestBody ReqDatatableParam data)
	{
		try {
			List<TUser> users = new ArrayList<TUser>();
			List<User> allUsers = userService.findAllUser(data.getStart(), data.getLength());
			int countAllUsers = userService.countAllUser();
			
			for (User user : allUsers) {
				String groups = groupService.findConcatGroupByUsername(user.getUsername());
				String branch = branchService.findById(user.getBranch_id()).getBranchName();
				users.add(new TUser(user.getId(), user.getUsername(), user.getFullname(), user.getStaff_id(), user.getPhone_number(), user.getEmail(), 
						groups, branch, user.getFailed_attempt(), user.isLocked(), user.isIs_active(), user.getCreated_at()));
			}
			
			return new ResDatatableParam<TUser>(data.getDraw(), countAllUsers, countAllUsers, users);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return null;
	}
	
	@PostMapping("/create")
	public ObjResponseEntity<String> userCreate(@RequestBody TUser data)
	{
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			User user = null;
			LdapUser ldapUser = ldapUserService.getLdapUser(data.getUsername());
			Branch branch = branchService.findById(data.getBranch_id());
			if(ldapUser == null) {
				return ObjResponseFactory.fail(ErrorMessage.LDAP_USER_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			if(branch == null || branch.isDeleted()) {
				return ObjResponseFactory.fail(ErrorMessage.BRANCH_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			
			user = userService.findByUsername(ldapUser.getsAMAccountName());
			if(user == null) {
				user = userService.save(new User(branch.getId(), ldapUser.getsAMAccountName(), ldapUser.getDisplayName(), ldapUser.getEmployeeID(), data.getPhone_number(),
												ldapUser.getUserPrincipalName(), 0, false, true, now, authUsername, false));
				
				for (Integer tGroup : data.getGroups()) {
					Group group = groupService.findById(tGroup.intValue());
					if(group == null) {
						return ObjResponseFactory.fail(ErrorMessage.GROUP_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
					}
					if(!userGroupService.save(new UserGroupDetail(String.valueOf(user.getId()), String.valueOf(group.getId()), authUsername, now, true, false))) {
						return ObjResponseFactory.fail(ErrorMessage.USER_CREATE_FAIL.getValue(), StatusMessageEnum.INTERNAL_SERVER_ERROR.getStatusCode());
					}
				}
			}else {
				user.setBranch_id(branch.getId());
				user.setUsername(ldapUser.getsAMAccountName());
				user.setFullname(ldapUser.getDisplayName());
				user.setStaff_id(ldapUser.getEmployeeID());
				user.setPhone_number(data.getPhone_number());
				user.setEmail(ldapUser.getUserPrincipalName());
				user.setFailed_attempt(0);
				user.setLocked(false);
				user.setIs_active(true);
				user.setCreated_at(now);
				user.setCreated_by(authUsername);
				user.setUpdated_at(null);
				user.setUpdated_by(null);
				user.setIs_deleted(false);
				user.setDeleted_at(null);
				user.setDeleted_by(null);
				userService.save(user);
				
				String userId = String.valueOf(user.getId());
				for (Integer groupId : data.getGroups()) {
					System.out.println(groupId.toString());
					UserGroupDetail exist = userGroupService.findByUserIdAndGroupId(userId, groupId.toString());
					if(exist != null) {
						exist.setIs_deleted(false);
						exist.setDeleted_at(null);
						exist.setDeleted_by(null);
						exist.setIs_active(true);
						exist.setUpdated_at(now);
						exist.setUpdated_by(authUsername);
						userGroupService.save(exist);
					}else {
						userGroupService.save(new UserGroupDetail(userId, groupId.toString(), authUsername, now, true, false));
					}
				}
			}
			
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/info")
	public ObjResponseEntity<User> userInfo(@RequestBody TUser data)
	{
		try {
			int userID = data.getId();
			User user = userService.findById(userID);
			return ObjResponseFactory.build(user);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/edit")
	public ObjResponseEntity<String> userEdit(@RequestBody TUser data)
	{
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			User user = userService.findById(data.getId());
			Branch branch = branchService.findById(data.getBranch_id());
			
			if(user == null || user.isIs_deleted()) {
				return ObjResponseFactory.fail(ErrorMessage.USER_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			if(branch == null || branch.isDeleted()) {
				return ObjResponseFactory.fail(ErrorMessage.BRANCH_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			String userId = String.valueOf(user.getId());
			user.setBranch_id(branch.getId());
			user.setIs_active(data.isIs_active());
			user.setLocked(data.isLocked());
			user.setPhone_number(data.getPhone_number());
			user.setUpdated_at(now);
			user.setUpdated_by(authUsername);
			userService.save(user);
			
			LdapUser ldapUser = ldapUserService.getLdapUser(user.getUsername());
			if(ldapUser == null) {
				return ObjResponseFactory.fail(ErrorMessage.LDAP_USER_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			
			List<UserGroupDetail> userGroupDetails = userGroupService.findByUserId(String.valueOf(user.getId()), 0);
			for (UserGroupDetail userGroupDetail : userGroupDetails) {
				userGroupDetail.setIs_deleted(true);
				userGroupDetail.setDeleted_at(now);
				userGroupDetail.setDeleted_by(authUsername);
				userGroupService.save(userGroupDetail);
			}
			
			for (Integer groupId : data.getGroups()) {
				System.out.println(groupId.toString());
				UserGroupDetail exist = userGroupService.findByUserIdAndGroupId(userId, groupId.toString());
				if(exist != null) {
					exist.setIs_deleted(false);
					exist.setDeleted_at(null);
					exist.setDeleted_by(null);
					exist.setIs_active(true);
					exist.setUpdated_at(now);
					exist.setUpdated_by(authUsername);
					userGroupService.save(exist);
				}else {
					userGroupService.save(new UserGroupDetail(userId, groupId.toString(), authUsername, now, true, false));
				}
			}
			
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/unlock")
	public ObjResponseEntity<String> userUnlock(@RequestBody TUser data)
	{
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			User user = userService.findById(data.getId());
			if(user == null) {
				return ObjResponseFactory.fail(ErrorMessage.USER_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			user.setLocked(false);
			user.setFailed_attempt(0);
			user.setUpdated_at(now);
			user.setUpdated_by(authUsername);
			userService.save(user);
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/delete")
	public ObjResponseEntity<String> userDelete(@RequestBody TUser data)
	{
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			String authUsername = SecurityContextHolder.getContext().getAuthentication().getName();
			User user = userService.findById(data.getId());
			if(user == null) {
				return ObjResponseFactory.fail(ErrorMessage.USER_NOT_FOUND.getValue(), StatusMessageEnum.NO_CONTENT.getStatusCode());
			}
			
			if(user.getUsername().equals(authUsername)) {
				return ObjResponseFactory.fail(ErrorMessage.CANNOT_DELETE_YOURSELF.getValue(), StatusMessageEnum.FORBIDDEN.getStatusCode());
			}
			
			user.setIs_deleted(true);
			user.setDeleted_at(now);
			user.setDeleted_by(authUsername);
			userService.save(user);
			
			List<UserGroupDetail> userGroupDetails = userGroupService.findByUserId(String.valueOf(user.getId()), 0);
			for (UserGroupDetail userGroupDetail : userGroupDetails) {
				userGroupDetail.setIs_deleted(true);
				userGroupDetail.setDeleted_at(now);
				userGroupDetail.setDeleted_by(authUsername);
				userGroupService.save(userGroupDetail);
			}
			
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@GetMapping("/sync")
	public ObjResponseEntity<String> userSync()
	{
		try {
			logger.info("===== Start sync user =====");
			Timestamp now = Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now()));
			List<User> users = userService.findUsers(0);
			for (User user : users) {
				DDMUser ddmUser = ddmUserService.findByUsername(user.getUsername());
				if(ddmUser != null) {
					if(!ddmUser.isActive()) {
						logger.info("User is inactive: " + user.getUsername());
						logger.info("Start deleting user: " + user.getUsername());
						user.setIs_active(false);
						user.setUpdated_at(now);
						user.setIs_deleted(true);
						user.setDeleted_at(now);
						userService.save(user);
						
						List<UserGroupDetail> userGroupDetails = userGroupService.findByUserId(String.valueOf(user.getId()), 0);
						for (UserGroupDetail userGroupDetail : userGroupDetails) {
							userGroupDetail.setIs_deleted(true);
							userGroupDetail.setDeleted_at(now);
							userGroupService.save(userGroupDetail);
						}
						logger.info("User deleted successfully: " + user.getUsername());
					}
				}else {
					logger.info("User is inactive: " + user.getUsername());
					logger.info("Start deleting user: " + user.getUsername());
					user.setIs_active(false);
					user.setUpdated_at(now);
					user.setIs_deleted(true);
					user.setDeleted_at(now);
					userService.save(user);
					
					List<UserGroupDetail> userGroupDetails = userGroupService.findByUserId(String.valueOf(user.getId()), 0);
					for (UserGroupDetail userGroupDetail : userGroupDetails) {
						userGroupDetail.setIs_deleted(true);
						userGroupDetail.setDeleted_at(now);
						userGroupService.save(userGroupDetail);
					}
					logger.info("User deleted successfully: " + user.getUsername());
				}
			}
			logger.info("===== End sync user =====");
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@GetMapping("/all-users")
	public ObjResponseEntity<List<User>> getAllUsers()
	{
		try {
			List<User> users = userService.findUsers(0);
			if(users.size() > 0) {
				return ObjResponseFactory.build(users);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
}
