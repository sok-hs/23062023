package com.aeon.internal.controller.ajax;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aeon.internal.entities.primary.Group;
import com.aeon.internal.entities.primary.RoleGroupDetail;
import com.aeon.internal.entities.primary.UserGroupDetail;
import com.aeon.internal.helper.ErrorMessage;
import com.aeon.internal.helper.ObjResponseEntity;
import com.aeon.internal.helper.ObjResponseFactory;
import com.aeon.internal.helper.StatusMessageEnum;
import com.aeon.internal.models.TGroup;
import com.aeon.internal.models.request.ReqDatatableParam;
import com.aeon.internal.models.response.ResDatatableParam;
import com.aeon.internal.service.primary.GroupService;
import com.aeon.internal.service.primary.RoleGroupService;
import com.aeon.internal.service.primary.UserGroupService;

@RestController
@RequestMapping("/setting/group")
@Transactional
public class GroupController {
	private static final Logger logger = LogManager.getLogger(String.class);
	
	@Autowired private GroupService groupService;
	@Autowired private RoleGroupService roleGroupService;
	@Autowired private UserGroupService userGroupService;
	
	@PostMapping("/datatable")
	public ResDatatableParam<Group> index(@RequestBody ReqDatatableParam data)
	{
		try {
			List<Group> groups = groupService.getAllGroups(data.getStart(), data.getLength());
			int countGroups = groupService.countAllGroups();
			return new ResDatatableParam<Group>(data.getDraw(), countGroups, countGroups, groups);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return null;
	}
	
	@PostMapping("/create")
	public ObjResponseEntity<String> createGroup(@RequestBody TGroup data)
	{
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			Group group = null;
			Group newGroup = null;
			String groupName = data.getGroupName();
			
//			Check existing group
			Group existingGroup = groupService.findExistingGroup(groupName.toLowerCase(), 0);
			Group existingDeletedGroup = groupService.findExistingGroup(groupName.toLowerCase(), 1);
			
			if(existingGroup != null) {
				return ObjResponseFactory.fail("Group is existed", StatusMessageEnum.CONFLICT.getStatusCode());
			}else if(existingDeletedGroup != null) {
				group = existingDeletedGroup;
				group.setIs_active(true);
				group.setCreated_at(now);
				group.setCreated_by(auth.getName());
				group.setIs_deleted(false);
				group.setDeleted_at(null);
				group.setDeleted_by(null);
				newGroup = groupService.save(group);
			}else {
				group = new Group(groupName, now, auth.getName());
				newGroup = groupService.save(group);
			}
		
			for (Integer role : data.getRoles()) {
				String roleId = String.valueOf(role.intValue());
				String groupId = String.valueOf(newGroup.getId());
				RoleGroupDetail roleGroup = null;
				
				RoleGroupDetail existingRoleGroup = roleGroupService.findExistingRoleGroup(roleId, groupId, 0);
				RoleGroupDetail existingDeletedRoleGroup = roleGroupService.findExistingRoleGroup(roleId, groupId, 1);
				if(existingGroup != null) {
					roleGroup = existingRoleGroup;
					roleGroup.setIs_active(true);
					roleGroup.setUpdated_at(now);
					roleGroup.setUpdated_by(auth.getName());
					roleGroup.setIs_deleted(false);
					roleGroup.setDeleted_at(null);
					roleGroup.setDeleted_by(null);
					roleGroupService.save(roleGroup);
				}else if (existingDeletedRoleGroup != null) {
					roleGroup = existingDeletedRoleGroup;
					roleGroup.setIs_active(true);
					roleGroup.setCreated_at(now);
					roleGroup.setCreated_by(auth.getName());
					roleGroup.setUpdated_at(null);
					roleGroup.setUpdated_by(null);
					roleGroup.setIs_deleted(false);
					roleGroup.setDeleted_at(null);
					roleGroup.setDeleted_by(null);
					roleGroupService.save(roleGroup);
				}else {
					System.out.println("New Group");
					roleGroup = new RoleGroupDetail(roleId, groupId, now, auth.getName());
					roleGroupService.save(roleGroup);
				}
			}
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@GetMapping("/get-all")
	public ObjResponseEntity<List<Group>> getAllGroups()
	{
		try {
			List<Group> groups = groupService.findAllGroups();
			return ObjResponseFactory.build(groups);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/get-group")
	public ObjResponseEntity<Group> getGroup(@RequestBody Group data)
	{
		try {
			Group group = groupService.findById(data.getId());
			return ObjResponseFactory.build(group);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/get-group-roles")
	public ObjResponseEntity<List<RoleGroupDetail>> getGroupRoleDetails(@RequestBody Group data)
	{
		try {
			String groupId = String.valueOf(data.getId());
			List<RoleGroupDetail> roleGroupDetails = roleGroupService.findByGroupId(groupId);
			return ObjResponseFactory.build(roleGroupDetails);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/edit")
	public ObjResponseEntity<String> editGroup(@RequestBody TGroup data)
	{
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			String authName = SecurityContextHolder.getContext().getAuthentication().getName();
			Group group = groupService.findById(data.getId());
			String groupIdString = String.valueOf(group.getId());
			List<RoleGroupDetail> roleGroupDetails = roleGroupService.findByGroupId(groupIdString);
			for (RoleGroupDetail roleGroupDetail : roleGroupDetails) {
				roleGroupDetail.setIs_deleted(true);
				roleGroupDetail.setDeleted_at(now);
				roleGroupDetail.setDeleted_by(authName);
				roleGroupService.save(roleGroupDetail);
			}
			for (Integer roleId : data.getRoles()) {
				String roleIdString = String.valueOf(roleId.intValue());
				RoleGroupDetail temp = roleGroupService.findExistingRoleGroup(roleIdString, groupIdString, 1);
				if(temp != null) {
					temp.setIs_deleted(false);
					temp.setDeleted_at(null);
					temp.setDeleted_by(null);
					temp.setIs_active(true);
					temp.setUpdated_at(now);
					temp.setUpdated_by(authName);
				}else {
					RoleGroupDetail newRoleGroup = new RoleGroupDetail(roleIdString, groupIdString, now, authName);
					roleGroupService.save(newRoleGroup);
				}
			}
			
			group.setGroup_name(data.getGroupName());
			groupService.save(group);
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}

	@PostMapping("/delete")
	public ObjResponseEntity<String> deleteGroup(@RequestBody Group data)
	{
		try {
			LocalTime localTime = LocalTime.now();
			Timestamp now = Timestamp.valueOf(localTime.atDate(LocalDate.now()));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			Group group = groupService.findById(data.getId());
			List<UserGroupDetail> userGroupDetails = userGroupService.findByGroupId(String.valueOf(group.getId()), 0);
			if(userGroupDetails.size() > 0) {
				return ObjResponseFactory.fail(ErrorMessage.GROUP_BEING_USED.getValue(), StatusMessageEnum.CONFLICT.getStatusCode());
			}
			
			List<RoleGroupDetail> roleGroupDetails = roleGroupService.findByGroupId(String.valueOf(group.getId()));
			
			for (RoleGroupDetail roleGroupDetail : roleGroupDetails) {
				roleGroupDetail.setIs_deleted(true);
				roleGroupDetail.setDeleted_at(now);
				roleGroupDetail.setDeleted_by(auth.getName());
				roleGroupService.save(roleGroupDetail);
			}
			
			group.setIs_deleted(true);
			group.setDeleted_at(now);
			group.setDeleted_by(auth.getName());
			
			return ObjResponseFactory.success();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
	
	@PostMapping("/user-group")
	public ObjResponseEntity<List<UserGroupDetail>> userGroup(@RequestBody UserGroupDetail data)
	{
		try {
			List<UserGroupDetail> userGroups = userGroupService.findByUserId(data.getUser_id(), 0);
			return ObjResponseFactory.build(userGroups);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ObjResponseFactory.fail();
	}
}
