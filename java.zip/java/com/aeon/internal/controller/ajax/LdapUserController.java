package com.aeon.internal.controller.ajax;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.aeon.internal.annotation.AjaxController;
import com.aeon.internal.models.LdapUser;
import com.aeon.internal.service.LdapUserServiceImpl;

@AjaxController
@RequestMapping("/ldap")
public class LdapUserController {
	
	@Autowired private LdapUserServiceImpl ldapUserServiceImpl;
	
	@GetMapping("/get")
	public LdapUser getLdapUser() {
		return ldapUserServiceImpl.getLdapUser("chchamroeun");
	}

}
