package com.aeon.internal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.stereotype.Service;

import com.aeon.internal.models.LdapUser;

@Service
public class LdapUserServiceImpl implements LdapUserService {
	
	@Autowired
	private LdapTemplate ldapTemplate;

	@Override
	public boolean isLdapUserExist(String username) {
		if(ldapTemplate.findOne(LdapQueryBuilder.query().where("sAMAccountName").is(username), LdapUser.class) != null) {
			return true;
		}
		return false;
	}

	@Override
	public boolean authenticateLdapUser(String username, String password) {
		AndFilter filter = new AndFilter();
		filter.and(new EqualsFilter("sAMAccountName", username));	
		return ldapTemplate.authenticate("", filter.encode(), password);
	}

	@Override
	public LdapUser getLdapUser(String username) {
		return ldapTemplate.findOne(LdapQueryBuilder.query().where("sAMAccountName").is(username), LdapUser.class);
	}

}