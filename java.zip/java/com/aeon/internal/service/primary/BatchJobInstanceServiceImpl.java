package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.BatchJobInstance;
import com.aeon.internal.repositories.primary.BatchJobInstanceRepository;

@Service
public class BatchJobInstanceServiceImpl implements BatchJobInstanceService {

	@Autowired BatchJobInstanceRepository batchJobInstanceRepository;

	@Override
	public List<BatchJobInstance> getAllReport() {
		return batchJobInstanceRepository.getAllReports();
	}

}
