package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.BatchJobInstance;

public interface BatchJobInstanceService {
	List<BatchJobInstance> getAllReport();
}
