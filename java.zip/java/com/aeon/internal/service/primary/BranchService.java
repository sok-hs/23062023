package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.Branch;

public interface BranchService {

	public boolean save(Branch branch);
	public Branch findById(int id);
	public Branch findExistBranchByBranchName(String branchName);
	public List<Branch> findDatatableAllBranches(int start, int length);
	public List<Branch> findAllBranches(int isDeleted);
	public int countAllBranch();
}
