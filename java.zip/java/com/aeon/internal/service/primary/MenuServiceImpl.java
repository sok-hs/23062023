package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.Menu;
import com.aeon.internal.repositories.primary.MenuRepository;

@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	private MenuRepository menuRepository;
	
	@Override
	public Menu findById(int id) {
		return menuRepository.findById(id);
	}

	@Override
	public List<Menu> getMenus(int length, int start) {
		return menuRepository.getAllMenus(length, start);
	}

	@Override
	public int countAllMenus() {
		return menuRepository.countAllMenus();
	}

	@Override
	public List<Menu> getParentMenus() {
		return menuRepository.getAllParentMenu();
	}

	@Override
	public boolean save(Menu menu) {
		try {
			menuRepository.save(menu);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Menu> getAllMenus() {
		return menuRepository.getAllMenus();
	}

	@Override
	public int existByMenuUrl(String url) {
		return menuRepository.existsByMenuUrl(url.toLowerCase());
	}

	@Override
	public Menu existByMenuName(String menuName, int isDeleted) {
		return menuRepository.existsByMenuName(menuName.toLowerCase(), isDeleted);
	}

	@Override
	public List<Menu> findAllByParentId(String parentId, int isDeleted) {
		return menuRepository.getAllMenuByParentId(parentId, isDeleted);
	}
	
	
}
