package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.Group;

public interface GroupService {

	Group findById(int id);
	List<Group> findAllGroups();
	List<Group> findGroupByUsername(String username);
	List<Group> getAllGroups(int start, int length);
	int countAllGroups();
	Group save(Group group);
	Group findExistingGroup(String groupName, int isDeleted);
	String findConcatGroupByUsername(String username);
}
