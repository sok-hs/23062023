package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.BatchJobExecution;

public interface BatchJobExecutionService {
	int countAllJobExecutions();
	List<BatchJobExecution> findAllJobExecutions();
}
