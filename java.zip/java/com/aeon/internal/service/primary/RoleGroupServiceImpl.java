package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.RoleGroupDetail;
import com.aeon.internal.repositories.primary.RoleGroupRepository;

@Service
public class RoleGroupServiceImpl implements RoleGroupService {

	@Autowired
	RoleGroupRepository roleGroupRepository;
	
	@Override
	public boolean save(RoleGroupDetail roleGroupDetail) {
		roleGroupRepository.save(roleGroupDetail);
		return true;
	}

	@Override
	public RoleGroupDetail findExistingRoleGroup(String roleId, String groupId, int isDeleted) {
		return roleGroupRepository.findExistingRoleGroup(roleId, groupId, isDeleted);
	}

	@Override
	public List<RoleGroupDetail> findByGroupId(String groupId) {
		return roleGroupRepository.findByGroupId(groupId);
	}

	@Override
	public List<RoleGroupDetail> findByRoleId(String roleId) {
		return roleGroupRepository.findAllByRoleId(roleId);
	}
	
}
