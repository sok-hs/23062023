package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.UserGroupDetail;
import com.aeon.internal.repositories.primary.UserGroupRepository;

@Service
public class UserGroupServiceImpl implements UserGroupService{

	@Autowired
	UserGroupRepository userGroupRepository;
	
	@Override
	public List<UserGroupDetail> findByUserId(String userId, int isDeleted) {
		return userGroupRepository.findByUserId(userId, isDeleted);
	}

	@Override
	public List<UserGroupDetail> findByGroupId(String groupId, int isDeleted) {
		return userGroupRepository.findByGroupId(groupId, isDeleted);
	}

	@Override
	public boolean save(UserGroupDetail userGroupDetail) {
		userGroupRepository.save(userGroupDetail);
		return true;
	}

	@Override
	public UserGroupDetail findByUserIdAndGroupId(String userId, String groupId) {
		return userGroupRepository.findByUserIdAndGroupId(userId, groupId);
	}

	
}
