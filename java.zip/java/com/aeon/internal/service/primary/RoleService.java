package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.Role;

public interface RoleService {
	
	List<String> findRoleByUsername(String username);
	List<Integer> findRoleObjByUsername(String username);
	
	List<String> getAllRoleTypes();
	List<Role> getRoles(int start, int length);
	int countAllRoles();
	Role findByRoleName(String roleName);
	Role findById(int id);
	Role findByMenuId(int menuId, int isDeleted);
	
	List<Role> getAllRoles();
	
	boolean save(Role role);
}
