package com.aeon.internal.service.primary;


import java.util.List;

import com.aeon.internal.entities.primary.RoleGroupDetail;

public interface RoleGroupService {
	boolean save(RoleGroupDetail roleGroupDetail);
	
	RoleGroupDetail findExistingRoleGroup(String roleId, String groupId, int isDeleted);
	
	List<RoleGroupDetail> findByGroupId(String groupId);
	List<RoleGroupDetail> findByRoleId(String roleId);
}
