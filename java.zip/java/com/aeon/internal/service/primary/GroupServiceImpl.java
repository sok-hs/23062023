package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.Group;
import com.aeon.internal.repositories.primary.GroupRepository;

@Service
public class GroupServiceImpl implements GroupService {

	@Autowired
	GroupRepository groupRepository;
	
	
	@Override
	public List<Group> findGroupByUsername(String username) {
		return groupRepository.findGroupByUsername(username);
	}

	@Override
	public Group findById(int id) {
		return groupRepository.findById(id);
	}

	@Override
	public List<Group> getAllGroups(int start, int length) {
		return groupRepository.getAllGroups(start, length);
	}

	@Override
	public int countAllGroups() {
		return groupRepository.countAllGroup();
	}

	@Override
	public Group save(Group group) {
		groupRepository.save(group);
		return group;
	}

	@Override
	public Group findExistingGroup(String groupName, int isDeleted) {
		return groupRepository.findExistGroupByGroupName(groupName, isDeleted);
	}

	@Override
	public String findConcatGroupByUsername(String username) {
		return groupRepository.findConcatGroupByUsername(username);
	}

	@Override
	public List<Group> findAllGroups() {
		return groupRepository.findAllGroups();
	}
	
}
