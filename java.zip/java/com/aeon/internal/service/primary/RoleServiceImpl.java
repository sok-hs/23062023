package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.Role;
import com.aeon.internal.repositories.primary.RoleRepository;

@Service
public class RoleServiceImpl implements RoleService {
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Override
	public List<String> findRoleByUsername(String username) {
		return roleRepository.findRoleByUsername(username);
	}
	
	@Override
	public List<Integer> findRoleObjByUsername(String username){
		return roleRepository.findRoleMenuIdByUsername(username);
	}

	@Override
	public List<Role> getRoles(int start, int length) {
		return roleRepository.getRoles(start, length);
	}

	@Override
	public List<String> getAllRoleTypes() {
		return roleRepository.getAllRoleTypes();
	}

	@Override
	public int countAllRoles() {
		return roleRepository.countAllRoles();
	}

	@Override
	public Role findByRoleName(String roleName) {
		return roleRepository.findByRoleName(roleName);
	}

	@Override
	public Role findById(int id) {
		return roleRepository.findById(id);
	}

	@Override
	public Role findByMenuId(int menuId, int isDeleted) {
		return roleRepository.findByMenuId(menuId, isDeleted);
	}

	@Override
	public boolean save(Role role) {
		try {
			roleRepository.save(role);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Role> getAllRoles() {
		return roleRepository.getAllRoles();
	}
	
}
