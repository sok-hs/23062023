package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.Menu;

public interface MenuService {
	
	Menu findById(int id);
	List<Menu> getMenus(int length, int start);
	int countAllMenus();
	List<Menu> getParentMenus();
	boolean save(Menu menu);
	List<Menu> getAllMenus();
	int existByMenuUrl(String url);
	Menu existByMenuName(String menuName, int isDeleted);
	List<Menu> findAllByParentId(String parentId, int isDeleted);
}
