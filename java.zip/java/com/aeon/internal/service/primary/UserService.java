package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.User;

public interface UserService {
	
	User findByUsername(String username);
	User findById(int id);
	List<User> findUsers(int isDeleted);
	List<User> findAllUser(int start, int length);
	List<User> findUsersByBranch(int branchId);
	int countAllUser();
	User save(User user);
}
