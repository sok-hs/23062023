package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.User;
import com.aeon.internal.repositories.primary.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public User findById(int id) {
		return userRepository.findById(id);
	}

	@Override
	public List<User> findUsers(int isDeleted) {
		return userRepository.findUsers(isDeleted);
	}

	@Override
	public List<User> findUsersByBranch(int branchId) {
		return userRepository.findUsersByBranch(branchId);
	}

	@Override
	public List<User> findAllUser(int start, int length) {
		return userRepository.findAllUsers(start, length);
	}

	@Override
	public int countAllUser() {
		return userRepository.countAllUsers();
	}

	@Override
	public User save(User user) {
		userRepository.save(user);
		return user;
	}
	
}
