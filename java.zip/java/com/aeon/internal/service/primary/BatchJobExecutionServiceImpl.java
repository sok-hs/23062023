package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.BatchJobExecution;
import com.aeon.internal.repositories.primary.BatchJobExecutionRepository;

@Service
public class BatchJobExecutionServiceImpl implements BatchJobExecutionService {

	@Autowired private BatchJobExecutionRepository batchJobExecutionRepository;
	
	
	@Override
	public int countAllJobExecutions() {
		return (int) batchJobExecutionRepository.count();
	}

	@Override
	public List<BatchJobExecution> findAllJobExecutions() {
		return batchJobExecutionRepository.findAll();
	}

}
