package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.UserGroupDetail;

public interface UserGroupService {
	List<UserGroupDetail> findByUserId(String userId, int isDeleted);
	List<UserGroupDetail> findByGroupId(String groupId, int isDeleted);
	UserGroupDetail findByUserIdAndGroupId(String userId, String groupId);
	boolean save(UserGroupDetail userGroupDetail);
}
