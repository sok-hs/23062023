package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.BatchJobHistory;
import com.aeon.internal.repositories.primary.BatchJobHistoryRepository;

@Service
public class BatchJobHistoryServiceImpl implements BatchJobHistoryService{

	@Autowired
	private BatchJobHistoryRepository batchJobHistoryRepository;
	
	

	@Override
	public List<BatchJobHistory> findAllJobs(String dateFrom, String dateTo, String reportName, String exportedBy,
			String reportStatus, String username, int start, int length) {
		return batchJobHistoryRepository.findAllJob(dateFrom, dateTo, reportName, exportedBy, reportStatus, username, start, length);
	}
	@Override
	public List<BatchJobHistory> getAllCompletedJobHistory() {
		return batchJobHistoryRepository.findAllByStatus(1);
	}
	@Override
	public List<BatchJobHistory> getAllJobHistory(int start, int length) {
		return batchJobHistoryRepository.findAllJobHistory(start, length);
	}
	@Override
	public List<BatchJobHistory> getAllJobHistory(String username, int start, int length) {
		return batchJobHistoryRepository.findAllJobHistory(username, start, length);
	}
	@Override
	public BatchJobHistory findById(int id) {
		return batchJobHistoryRepository.findById(id);
	}

	@Override
	public List<BatchJobHistory> getAllJobHistory(String username, String jobName, int start, int length) {
		return batchJobHistoryRepository.findAllJobHistoryByUsername(username, jobName, start, length);
	}

	@Override
	public int countAllJob() {
		return batchJobHistoryRepository.countAllJobHistory();
	}
	
	@Override
	public int countAllJob(String username) {
		return batchJobHistoryRepository.countAllJobHistory(username);
	}

	@Override
	public int countAllJob(String jobName, String username) {
		return batchJobHistoryRepository.countAllJobHistory(jobName, username);
	}

	@Override
	public boolean save(BatchJobHistory batchJobHistory) {
		if(batchJobHistory != null) {
			batchJobHistoryRepository.save(batchJobHistory);
			return true;
		}
		return false;
	}
	
	@Override
	public int countReportStatus(String exitCode) {
		if(exitCode == "EXPIRED") {
			return batchJobHistoryRepository.countAllExpiredJobHistory();
		}
		return batchJobHistoryRepository.countByExitCode(exitCode);
	}
	
	@Override
	public int countReportStatus(String username, String exitCode) {
		if(exitCode == "EXPIRED") {
			return batchJobHistoryRepository.countAllExpiredJobHistory(username);
		}
		return batchJobHistoryRepository.countByExitCode(username, exitCode);
	}
	
	

}
