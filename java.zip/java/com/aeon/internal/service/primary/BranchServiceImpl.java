package com.aeon.internal.service.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.Branch;
import com.aeon.internal.repositories.primary.BranchRepository;

@Service
public class BranchServiceImpl implements BranchService {

	@Autowired BranchRepository branchRepository;
	
	
	@Override
	public boolean save(Branch branch) {
		try {
			branchRepository.save(branch);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Branch findById(int id) {
		return branchRepository.findById(id);
	}

	@Override
	public Branch findExistBranchByBranchName(String branchName) {
		return branchRepository.findBranchByBranchName(branchName.trim().toLowerCase());
	}

	@Override
	public List<Branch> findDatatableAllBranches(int start, int length) {
		return branchRepository.findDatatableAllBranches(start, length);
	}

	@Override
	public List<Branch> findAllBranches(int isDeleted) {
		return branchRepository.findAllBranches(isDeleted);
	}

	@Override
	public int countAllBranch() {
		return branchRepository.countAllBranches();
	}

}
