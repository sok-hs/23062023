package com.aeon.internal.service.primary;

import java.util.List;

import com.aeon.internal.entities.primary.BatchJobHistory;

public interface BatchJobHistoryService {
	BatchJobHistory findById(int id);
	List<BatchJobHistory> findAllJobs(String dateFrom, String dateTo, String reportName, String exportedBy, String reportStatus, String username, int start, int length);
	List<BatchJobHistory> getAllCompletedJobHistory();
	List<BatchJobHistory> getAllJobHistory(int start, int length);
	List<BatchJobHistory> getAllJobHistory(String username, int start, int length);
	List<BatchJobHistory> getAllJobHistory(String username, String jobName, int start, int length);
	int countAllJob();
	int countAllJob(String username);
	int countAllJob(String jobName, String username);
	int countReportStatus(String exitCode);
	int countReportStatus(String username, String exitCode);
	boolean save(BatchJobHistory batchJobHistory);
}
