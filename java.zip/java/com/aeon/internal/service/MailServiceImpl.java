package com.aeon.internal.service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.User;
import com.aeon.internal.service.primary.UserService;

@Service
public class MailServiceImpl implements MailService {
	private static final Logger logger = LogManager.getLogger(String.class);
	private final JavaMailSender javaMailSender;
	
	@Value("${application.name}") private String applicationName;
	@Autowired private UserService userService;
	@Autowired
	public MailServiceImpl (JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}
	
	@Override
	public boolean sendMail(String to, String subject, String content) throws MessagingException {
		try {
			User user = userService.findByUsername(to);
			MimeMessage msg = javaMailSender.createMimeMessage();
			// true = multipart message
	        MimeMessageHelper helper = new MimeMessageHelper(msg);
	        helper.setFrom("no-reply@aeon.com.kh");
	        helper.setTo(user.getEmail());

	        helper.setSubject(applicationName + " - " + subject);

	        // true = text/html
	        helper.setText(content, true);

	        javaMailSender.send(msg);
	        return true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return false;
			
		}
	}

}
