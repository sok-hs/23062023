package com.aeon.internal.service.tertiary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.tertiary.DDMUser;
import com.aeon.internal.repositories.tertiary.DDMUserRepository;

@Service
public class DDMUserServiceImpl implements DDMUserService {

	@Autowired DDMUserRepository ddmUserRepository;

	@Override
	public DDMUser findByUsername(String username) {
		return ddmUserRepository.findByNameIgnoreCase(username.toLowerCase());
	}

	@Override
	public DDMUser findByEmail(String email) {
		return ddmUserRepository.findByEmailIgnoreCase(email.toLowerCase());
	}
	
}
