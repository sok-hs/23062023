package com.aeon.internal.service.tertiary;

import com.aeon.internal.entities.tertiary.DDMUser;

public interface DDMUserService {
	public DDMUser findByUsername(String username);
	public DDMUser findByEmail(String email);
}
