package com.aeon.internal.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.aeon.internal.entities.primary.Group;
import com.aeon.internal.entities.primary.Role;
import com.aeon.internal.entities.primary.User;
import com.aeon.internal.helper.ErrorMessage;
import com.aeon.internal.models.UserDetail;
import com.aeon.internal.repositories.primary.GroupRepository;
import com.aeon.internal.repositories.primary.RoleRepository;
import com.aeon.internal.repositories.primary.UserRepository;

@Service
public class UserDetailService implements UserDetailsService {
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private GroupRepository groupRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByUsername(username);
		List<String> roles = new ArrayList<String>();
		if(user == null) {
			throw new UsernameNotFoundException(ErrorMessage.USER_NOT_FOUND.getValue());
		}
		
		List<Group> groups = groupRepository.findGroupByUserId(user.getId());
		boolean superAdmin = groups.stream().anyMatch(g -> g.getGroup_name().equals("Super Admin"));
		if(superAdmin) {
			List<Role> allRoles = roleRepository.getAllRoles();
			for (Role role : allRoles) {
				roles.add(role.getRole_name());
			}
		}else {
			for (Group group : groups) {
				List<Role> tempRoles = roleRepository.findRoleByGroupId(group.getId());
				for (Role tempRole : tempRoles) {
					roles.add(tempRole.getRole_name());
				}
			}
		}
		return new UserDetail((long) user.getId(), user.getUsername(), user.getFullname(), user.getPhone_number(), user.getEmail(), roles, groups);
	}
}