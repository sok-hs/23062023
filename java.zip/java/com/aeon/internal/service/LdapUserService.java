package com.aeon.internal.service;

import com.aeon.internal.models.LdapUser;

public interface LdapUserService {
	
	boolean isLdapUserExist(String username);
	boolean authenticateLdapUser(String username, String password);
	LdapUser getLdapUser(String username);

}
