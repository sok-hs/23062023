package com.aeon.internal.configuration;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.aeon.internal.entities.primary.User;
import com.aeon.internal.entities.primary.UserGroupDetail;
import com.aeon.internal.entities.tertiary.DDMUser;
import com.aeon.internal.service.primary.UserGroupService;
import com.aeon.internal.service.primary.UserService;
import com.aeon.internal.service.tertiary.DDMUserService;

/*
 * 
 * For scheduling task
 * 
 * */

@Component
public class Scheduler {
	private static final Logger logger = LogManager.getLogger(String.class);
	
	@Autowired UserService userService;
	@Autowired DDMUserService ddmUserService;
	@Autowired UserGroupService userGroupService;
	
	@Scheduled(cron = "0 5 0 * * ?")
	public void syncUser() {
		logger.info("===== Start sync user by schedule =====");
		Timestamp now = Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now()));
		List<User> users = userService.findUsers(0);
		for (User user : users) {
			DDMUser ddmUser = ddmUserService.findByUsername(user.getUsername());
			if(ddmUser != null) {
				if(!ddmUser.isActive()) {
					logger.info("User is inactive: " + user.getUsername());
					logger.info("Start deleting user: " + user.getUsername());
					user.setIs_active(false);
					user.setUpdated_at(now);
					user.setIs_deleted(true);
					user.setDeleted_at(now);
					userService.save(user);
					
					List<UserGroupDetail> userGroupDetails = userGroupService.findByUserId(String.valueOf(user.getId()), 0);
					for (UserGroupDetail userGroupDetail : userGroupDetails) {
						userGroupDetail.setIs_deleted(true);
						userGroupDetail.setDeleted_at(now);
						userGroupService.save(userGroupDetail);
					}
					logger.info("User deleted successfully: " + user.getUsername());
				}
			}else {
				logger.info("User not found in LDPA: " + user.getUsername());
				logger.info("Start deleting user: " + user.getUsername());
				user.setIs_active(false);
				user.setUpdated_at(now);
				user.setIs_deleted(true);
				user.setDeleted_at(now);
				userService.save(user);
				
				List<UserGroupDetail> userGroupDetails = userGroupService.findByUserId(String.valueOf(user.getId()), 0);
				for (UserGroupDetail userGroupDetail : userGroupDetails) {
					userGroupDetail.setIs_deleted(true);
					userGroupDetail.setDeleted_at(now);
					userGroupService.save(userGroupDetail);
				}
				logger.info("User deleted successfully: " + user.getUsername());
			}
		}
		logger.info("===== End sync user by schedule =====");
	}
}
