package com.aeon.internal.configuration;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.aeon.internal.entities.primary.User;
import com.aeon.internal.models.UserDetail;
import com.aeon.internal.service.LdapUserServiceImpl;
import com.aeon.internal.service.UserDetailService;
import com.aeon.internal.service.primary.UserService;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {
	
	@Autowired private LdapUserServiceImpl ldapService;
	@Autowired private UserDetailService userDetailService;
	@Autowired private UserService userService;
	
//	final static Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);
	private static final Logger logger = LogManager.getLogger(CustomAuthenticationProvider.class);
	

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException{

        String username = authentication.getName();
//        String password = authentication.getCredentials().toString();
        //By password
        String password = "";
        
        try{        	
			if(username != null && password != null) {
				boolean isLdapExist = ldapService.isLdapUserExist(username);
				if(!isLdapExist) {
					throw new UsernameNotFoundException("Could not find user");
				}
				
	    		Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
	        	if(ldapService.authenticateLdapUser(username, password)) {
	        		User user = userService.findByUsername(username);
	        		
	        		if(user.isLocked()) {
	        			throw new LockedException("This user is locked");
	        		}
	        		
	        		if(!user.isIs_active()) {
	        			throw new LockedException("This user is inactive");
	        		}
	        		
//	        		Update user last login timestamp
	        		user.setLast_login(Timestamp.valueOf(LocalTime.now().atDate(LocalDate.now())));
	        		userService.save(user);
	        		
	        		UserDetail userDetail = (UserDetail) userDetailService.loadUserByUsername(username);
	        		Collection<? extends GrantedAuthority> authorities = userDetail.getAuthorities();
	        		for (GrantedAuthority grantedAuthority : authorities) {
	        			grantedAuthorities.add(new SimpleGrantedAuthority(grantedAuthority.getAuthority()));
					}
	                return new UsernamePasswordAuthenticationToken(username, password, grantedAuthorities);
	            }else {
	            	int failAttempts = 0;
	        		User user = userService.findByUsername(username);
	        		failAttempts = user.getFailed_attempt();
	        		if(failAttempts >= 3) {
	        			user.setLocked(true);
	        		}else {
	        			user.setFailed_attempt(failAttempts + 1);
	        		}
	        		userService.save(user);
	        		if(user.isLocked()) {
	        			throw new LockedException("User is locked");
	        		}else {
	        			throw new AuthenticationCredentialsNotFoundException("Username or Password is not correct");
	        		}
	            }
			}
        }catch(Exception e) {
        	e.printStackTrace();
        	logger.error("Error: ", e);
        } 
        throw new BadCredentialsException("Bad Requested");
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}
}
